# FUJAZ PLAY para Windows

Versão inicial do FUJAZ PLAY feita especificamente para Windows 10/11 (x64), usando .NET 8 + WPF + LibVLCSharp.

## O que já está nesta versão

- Login Xtream Codes por nome da lista, usuário, senha e DNS.
- Múltiplas listas salvas, com conectar, editar e excluir.
- Credenciais protegidas pelo Windows (DPAPI) para o usuário atual.
- Tela inicial no visual FUJAZ PLAY, usando o wallpaper original.
- Canais ao vivo, Filmes, Séries e Futebol.
- Futebol procura categorias por prioridade: `Jogos de Hoje`, `Jogos do Dia`, `Jogos`, `Futebol ao Vivo` e `Futebol`. Também encontra nomes que contenham esses termos, por exemplo `Futebol Abracadabra`.
- Pesquisa global dentro de cada seção, sem precisar de categoria `Todos`.
- Player LibVLC para canais, filmes e episódios.
- Em canais ao vivo, ENTER abre a lista sobreposta e ela fecha após 5 segundos de inatividade. ESC fecha imediatamente.
- Barra de progresso em filmes e episódios, com ←/→ para voltar/adiantar 15 segundos.
- Continuar assistindo salvo separadamente para cada lista.
- Atualização completa de conteúdos toda vez que o aplicativo abre.
- Botão `ATUALIZAR CONTEÚDOS` na Home para atualizar manualmente.
- `ATUALIZAR CONTA` continua separado, consultando apenas a situação da conta.
- Botão Futebol com destaque laranja; demais botões usam azul/ciano.
- Botão Wi-Fi abre as configurações de rede do Windows.

## Como gerar o EXE no GitHub

1. Crie um repositório novo no GitHub, por exemplo `Fujaz-play-windows`.
2. Envie **todo o conteúdo deste ZIP** para a raiz do repositório.
3. Abra a aba **Actions** e execute `Build FUJAZ PLAY Windows` (ou aguarde o build automático após enviar os arquivos).
4. Ao terminar, baixe o artifact `FUJAZ-PLAY-Windows`.
5. Dentro dele estarão:
   - `FUJAZ-PLAY-Windows-Setup.exe` — instalador.
   - `FUJAZ-PLAY-Windows-Portable.zip` — versão portátil.

## Observações

- O projeto não contém usuário, senha, DNS ou lista IPTV embutida.
- O aplicativo foi preparado para serviços compatíveis com Xtream Codes.
- Alguns servidores usam formatos próprios ou dados de séries fora do padrão. Se encontrar um servidor que não carregue corretamente, use o erro/tela como referência para ajustar a compatibilidade na próxima versão.
- Esta é a primeira base Windows. Recursos mais específicos do app Android, como EPG avançado, atualização online do próprio aplicativo e a tela de futebol baseada no guia de programação, podem ser adicionados nas próximas versões sem precisar refazer o projeto.
