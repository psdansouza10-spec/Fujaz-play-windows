# FUJAZ PLAY Windows

Versão Windows reconstruída tomando o FUJAZ PLAY Android 17.34 como referência direta.

## Alterações desta base
- Uma única janela principal: Login, Home, Canais, Filmes, Séries, Futebol, Continuar Assistindo, Minha Conta, detalhes e Player navegam dentro da mesma janela.
- Home com os mesmos botões da versão Android e FUTEBOL com destaque laranja.
- Login inicial exclusivo quando não há lista salva, com mostrar/ocultar senha e botão ENTRAR.
- Atualização de conteúdos em toda abertura e botão manual ATUALIZAR CONTEÚDOS.
- Minha Conta com Conectar, Salvar/Editar, Excluir, Adicionar Lista e Atualizar Conta.
- Player reutiliza uma única instância do LibVLC durante a sessão.
- Catálogo paginado em blocos de 30 itens para reduzir uso de memória e travamentos.
- Listas com virtualização/recycling quando aplicável.
- Requisições e parse de conteúdo usam continuations fora da thread da interface para reduzir “Não está respondendo”.
- Lista sobreposta de canais no player fecha após 5 segundos sem atividade e reinicia o tempo ao navegar.

## Build
O projeto continua compatível com o workflow do repositório que extrai `FUJAZ-PLAY-Windows-GitHub.zip`.
