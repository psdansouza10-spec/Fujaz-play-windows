#define MyAppName "FUJAZ PLAY"
#define MyAppVersion "1.0.0"
#define MyAppPublisher "FUJAZ PLAY"
#define MyAppExeName "FUJAZ-PLAY.exe"

[Setup]
AppId={{90F6D602-7A89-4F96-80B1-84606B3B9B60}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\FUJAZ PLAY
DefaultGroupName=FUJAZ PLAY
AllowNoIcons=yes
OutputDir=output
OutputBaseFilename=FUJAZ-PLAY-Windows-Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
SetupIconFile=..\src\FujazPlay.Windows\Assets\app.ico
UninstallDisplayIcon={app}\{#MyAppExeName}
PrivilegesRequired=lowest

[Files]
Source: "..\publish\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autoprograms}\FUJAZ PLAY"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\FUJAZ PLAY"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "Criar atalho na área de trabalho"; GroupDescription: "Atalhos:"; Flags: unchecked

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Abrir FUJAZ PLAY"; Flags: nowait postinstall skipifsilent
