namespace FujazPlay.Windows.Models;

public sealed class ContentCache
{
    public List<CategoryItem> LiveCategories { get; set; } = new();
    public List<StreamItem> LiveStreams { get; set; } = new();
    public List<CategoryItem> VodCategories { get; set; } = new();
    public List<StreamItem> VodStreams { get; set; } = new();
    public List<CategoryItem> SeriesCategories { get; set; } = new();
    public List<StreamItem> Series { get; set; } = new();
    public long UpdatedAt { get; set; }
}
