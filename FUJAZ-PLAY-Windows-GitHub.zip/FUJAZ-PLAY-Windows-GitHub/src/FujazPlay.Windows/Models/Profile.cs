using System.Text.Json.Serialization;

namespace FujazPlay.Windows.Models;

public sealed class Profile
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Name { get; set; } = "Minha Lista";
    public string Dns { get; set; } = string.Empty;
    public string Username { get; set; } = string.Empty;
    public string PasswordProtected { get; set; } = string.Empty;
    public long UpdatedAt { get; set; } = DateTimeOffset.UtcNow.ToUnixTimeSeconds();

    [JsonIgnore]
    public string DisplayName => string.IsNullOrWhiteSpace(Name) ? "Minha Lista" : Name.Trim();
}
