namespace FujazPlay.Windows.Models;

public sealed class AccountInfo
{
    public string Status { get; set; } = string.Empty;
    public string ExpDate { get; set; } = string.Empty;
    public string MaxConnections { get; set; } = string.Empty;
    public string ActiveConnections { get; set; } = string.Empty;
    public string LiveExtension { get; set; } = "m3u8";
}
