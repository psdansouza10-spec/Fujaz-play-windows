namespace FujazPlay.Windows.Models;

public sealed class EpisodeItem
{
    public string Id { get; set; } = string.Empty;
    public string SeriesId { get; set; } = string.Empty;
    public string SeriesTitle { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
    public int Season { get; set; }
    public int Episode { get; set; }
    public string Extension { get; set; } = "mp4";
    public string IconUrl { get; set; } = string.Empty;
    public string Plot { get; set; } = string.Empty;

    public string DisplayTitle => Episode > 0 ? $"E{Episode:00}  {Title}" : Title;
}
