namespace FujazPlay.Windows.Models;

public sealed class StreamItem
{
    public string Kind { get; set; } = string.Empty; // live, movie, series
    public string Id { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
    public string CategoryId { get; set; } = string.Empty;
    public string IconUrl { get; set; } = string.Empty;
    public string Extension { get; set; } = string.Empty;
    public string Plot { get; set; } = string.Empty;
    public string Rating { get; set; } = string.Empty;
    public string EpgChannelId { get; set; } = string.Empty;
    public long Added { get; set; }

    public string Subtitle
    {
        get
        {
            if (!string.IsNullOrWhiteSpace(Rating)) return $"★ {Rating}";
            return Kind switch
            {
                "live" => "Canal ao vivo",
                "movie" => "Filme",
                "series" => "Série",
                _ => string.Empty
            };
        }
    }
}
