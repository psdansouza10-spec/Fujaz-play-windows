namespace FujazPlay.Windows.Models;

public enum CatalogSection { Live, Movies, Series }
