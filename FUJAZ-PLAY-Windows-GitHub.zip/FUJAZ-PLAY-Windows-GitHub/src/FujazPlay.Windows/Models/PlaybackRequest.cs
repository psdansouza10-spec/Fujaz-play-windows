namespace FujazPlay.Windows.Models;

public sealed class PlaybackRequest
{
    public string Kind { get; set; } = string.Empty;
    public string Id { get; set; } = string.Empty;
    public string ParentId { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
    public string Subtitle { get; set; } = string.Empty;
    public string Url { get; set; } = string.Empty;
    public string IconUrl { get; set; } = string.Empty;
    public string Extension { get; set; } = string.Empty;
    public bool IsLive => Kind == "live";
}
