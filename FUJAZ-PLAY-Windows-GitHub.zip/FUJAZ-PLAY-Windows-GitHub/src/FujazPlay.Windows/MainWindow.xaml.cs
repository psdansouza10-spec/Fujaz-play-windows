using System.Diagnostics;
using System.Globalization;
using System.Text.Json.Nodes;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using FujazPlay.Windows.Models;
using FujazPlay.Windows.Services;
using LibVLCSharp.Shared;

namespace FujazPlay.Windows;

public partial class MainWindow : Window
{
    private enum Screen { Login, Home, Catalog, Detail, Series, Continue, Account, Player }

    private readonly AppServices _services;
    private readonly DispatcherTimer _clock = new() { Interval = TimeSpan.FromSeconds(1) };
    private readonly DispatcherTimer _playerUiTimer = new() { Interval = TimeSpan.FromSeconds(1) };
    private readonly DispatcherTimer _overlayTimer = new() { Interval = TimeSpan.FromSeconds(5) };
    private readonly Stack<Screen> _history = new();
    private Screen _screen;
    private Profile? _activeProfile;
    private AccountInfo? _accountInfo;
    private bool _busy;
    private bool _syncingPassword;

    private CatalogSection _catalogSection;
    private List<CategoryItem> _catalogCategories = new();
    private List<StreamItem> _catalogAll = new();
    private List<StreamItem> _catalogFiltered = new();
    private string? _forcedCategoryId;
    private int _catalogPage;
    private const int PageSize = 30;
    private XtreamClient? _catalogClient;
    private StreamItem? _detailItem;

    private readonly SortedDictionary<int, List<EpisodeItem>> _seriesSeasons = new();
    private StreamItem? _currentSeries;
    private XtreamClient? _seriesClient;

    private LibVLC? _libVlc;
    private MediaPlayer? _mediaPlayer;
    private Media? _media;
    private XtreamClient? _liveClient;
    private PlaybackRequest? _playRequest;
    private List<StreamItem> _livePlaylist = new();
    private int _liveIndex;
    private bool _seeking;
    private bool _resumeApplied;

    public MainWindow() : this(new AppServices(), null) { }

    public MainWindow(AppServices services, Profile? activeProfile = null)
    {
        _services = services;
        _activeProfile = activeProfile;
        InitializeComponent();
        _clock.Tick += (_, _) => UpdateClock();
        _clock.Start();
        _playerUiTimer.Tick += (_, _) => RefreshPlayerUi();
        _overlayTimer.Tick += (_, _) => HideLiveOverlay();
        UpdateClock();
        Loaded += MainWindow_Loaded;
        Closed += MainWindow_Closed;
    }

    private async void MainWindow_Loaded(object sender, RoutedEventArgs e)
    {
        _activeProfile ??= _services.Profiles.GetActiveProfile();
        if (_activeProfile is null)
        {
            Navigate(Screen.Login, false);
            LoginNameBox.Focus();
            return;
        }
        Navigate(Screen.Home, false);
        await RefreshContentsAsync(true);
        LiveButton.Focus();
    }

    private void UpdateClock()
    {
        var now = DateTime.Now;
        ClockText.Text = now.ToString("HH:mm");
        SecondsText.Text = now.ToString("ss");
        DateText.Text = now.ToString("ddd, dd MMM", new CultureInfo("pt-BR"));
    }

    private void Navigate(Screen target, bool push = true)
    {
        if (push && target != _screen) _history.Push(_screen);
        _screen = target;
        LoginView.Visibility = target == Screen.Login ? Visibility.Visible : Visibility.Collapsed;
        HomeView.Visibility = target == Screen.Home ? Visibility.Visible : Visibility.Collapsed;
        CatalogView.Visibility = target == Screen.Catalog ? Visibility.Visible : Visibility.Collapsed;
        DetailView.Visibility = target == Screen.Detail ? Visibility.Visible : Visibility.Collapsed;
        SeriesView.Visibility = target == Screen.Series ? Visibility.Visible : Visibility.Collapsed;
        ContinueView.Visibility = target == Screen.Continue ? Visibility.Visible : Visibility.Collapsed;
        AccountView.Visibility = target == Screen.Account ? Visibility.Visible : Visibility.Collapsed;
        PlayerView.Visibility = target == Screen.Player ? Visibility.Visible : Visibility.Collapsed;
    }

    private void GoBack()
    {
        if (_screen == Screen.Player)
        {
            StopPlayback();
        }
        if (_history.Count > 0)
        {
            var previous = _history.Pop();
            Navigate(previous, false);
            FocusCurrentScreen();
            return;
        }
        if (_screen == Screen.Home) ShowExit();
    }

    private void FocusCurrentScreen()
    {
        switch (_screen)
        {
            case Screen.Home: LiveButton.Focus(); break;
            case Screen.Catalog: CatalogCategoriesList.Focus(); break;
            case Screen.Series: EpisodesList.Focus(); break;
            case Screen.Continue: ContinueList.Focus(); break;
            case Screen.Account: ProfilesList.Focus(); break;
            case Screen.Login: LoginNameBox.Focus(); break;
        }
    }

    private void SetBusy(bool value, string title = "Carregando…", string message = "")
    {
        _busy = value;
        BusyBorder.Visibility = value ? Visibility.Visible : Visibility.Collapsed;
        BusyTitle.Text = title;
        BusyMessage.Text = message;
        IsHitTestVisible = !value;
        BusyBorder.IsHitTestVisible = true;
    }

    private async Task RefreshContentsAsync(bool firstOpen)
    {
        if (_activeProfile is null || _busy) return;
        var progress = new Progress<string>(s => BusyMessage.Text = s);
        SetBusy(true, firstOpen ? "Preparando o FUJAZ PLAY…" : "Atualizando conteúdos…", "Conectando à lista ativa…");
        try
        {
            var result = await _services.Content.RefreshAsync(_activeProfile, progress);
            _accountInfo = result.Account;
            ActiveListText.Text = $"LISTA ATIVA: {_activeProfile.DisplayName}";
            HomeStatusText.Text = $"Conteúdos atualizados • {DateTime.Now:HH:mm}";
        }
        catch (Exception ex)
        {
            var cached = _services.Content.TryGet(_activeProfile);
            HomeStatusText.Text = cached is not null ? "Servidor não respondeu agora • usando conteúdo salvo" : ex.Message;
        }
        finally { SetBusy(false); }
    }

    private ContentCache? GetCache()
    {
        if (_activeProfile is null) return null;
        return _services.Content.TryGet(_activeProfile);
    }

    // LOGIN
    private void LoginPasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
    {
        if (_syncingPassword) return;
        _syncingPassword = true;
        LoginPasswordTextBox.Text = LoginPasswordBox.Password;
        _syncingPassword = false;
    }

    private void LoginPasswordTextBox_TextChanged(object sender, TextChangedEventArgs e)
    {
        if (_syncingPassword) return;
        _syncingPassword = true;
        LoginPasswordBox.Password = LoginPasswordTextBox.Text;
        _syncingPassword = false;
    }

    private void PasswordEye_Click(object sender, RoutedEventArgs e)
    {
        if (LoginPasswordBox.Visibility == Visibility.Visible)
        {
            LoginPasswordTextBox.Visibility = Visibility.Visible;
            LoginPasswordBox.Visibility = Visibility.Collapsed;
            LoginPasswordTextBox.Focus();
            LoginPasswordTextBox.CaretIndex = LoginPasswordTextBox.Text.Length;
        }
        else
        {
            LoginPasswordBox.Visibility = Visibility.Visible;
            LoginPasswordTextBox.Visibility = Visibility.Collapsed;
            LoginPasswordBox.Focus();
        }
    }

    private async void Login_Click(object sender, RoutedEventArgs e)
    {
        LoginErrorText.Text = string.Empty;
        var name = string.IsNullOrWhiteSpace(LoginNameBox.Text) ? "Minha Lista" : LoginNameBox.Text.Trim();
        var user = LoginUserBox.Text.Trim();
        var pass = LoginPasswordBox.Password;
        var dns = LoginDnsBox.Text.Trim();
        if (string.IsNullOrWhiteSpace(user) || string.IsNullOrWhiteSpace(pass) || string.IsNullOrWhiteSpace(dns))
        {
            LoginErrorText.Text = "Preencha usuário, senha e DNS/Servidor.";
            return;
        }
        SetBusy(true, "Conectando…", "Validando sua lista.");
        try
        {
            using var client = new XtreamClient(dns, user, pass);
            _accountInfo = await client.LoginAsync();
            var profile = new Profile { Name = name, Username = user, Dns = XtreamClient.NormalizeDns(dns) };
            _services.Profiles.SaveProfile(profile, pass);
            _services.Profiles.SetActive(profile.Id);
            _activeProfile = profile;
            ActiveListText.Text = $"LISTA ATIVA: {profile.DisplayName}";
            Navigate(Screen.Home, false);
            _history.Clear();
            SetBusy(false);
            await RefreshContentsAsync(true);
            LiveButton.Focus();
        }
        catch (Exception ex)
        {
            SetBusy(false);
            LoginErrorText.Text = ex.Message;
        }
    }

    // HOME
    private void Live_Click(object sender, RoutedEventArgs e) => OpenCatalog(CatalogSection.Live, null, null);
    private void Movies_Click(object sender, RoutedEventArgs e) => OpenCatalog(CatalogSection.Movies, null, null);
    private void Series_Click(object sender, RoutedEventArgs e) => OpenCatalog(CatalogSection.Series, null, null);

    private void Football_Click(object sender, RoutedEventArgs e)
    {
        var cache = GetCache();
        if (cache is null) { HomeStatusText.Text = "Atualize os conteúdos primeiro."; return; }
        var category = ContentService.FindFootballCategory(cache.LiveCategories);
        if (category is null) { HomeStatusText.Text = "Nenhuma pasta de Jogos/Futebol encontrada nesta lista."; return; }
        OpenCatalog(CatalogSection.Live, category.Id, "FUTEBOL");
    }

    private void Continue_Click(object sender, RoutedEventArgs e)
    {
        if (_activeProfile is null) return;
        var rows = _services.History.ContinueWatching(_activeProfile.Id).Select(x => new ContinueRow(x)).ToList();
        ContinueList.ItemsSource = rows;
        Navigate(Screen.Continue);
        ContinueList.Focus();
    }

    private void Wifi_Click(object sender, RoutedEventArgs e)
    {
        try { Process.Start(new ProcessStartInfo("ms-settings:network-wifi") { UseShellExecute = true }); }
        catch { try { Process.Start(new ProcessStartInfo("ms-settings:network") { UseShellExecute = true }); } catch { } }
    }

    private void Account_Click(object sender, RoutedEventArgs e)
    {
        LoadProfiles();
        Navigate(Screen.Account);
        ProfilesList.Focus();
    }

    private async void Refresh_Click(object sender, RoutedEventArgs e) => await RefreshContentsAsync(false);

    // CATALOG
    private void OpenCatalog(CatalogSection section, string? forcedCategoryId, string? titleOverride)
    {
        var cache = GetCache();
        if (cache is null || _activeProfile is null) { HomeStatusText.Text = "Ainda não há conteúdo carregado."; return; }
        _catalogSection = section;
        _forcedCategoryId = forcedCategoryId;
        (_catalogCategories, _catalogAll) = section switch
        {
            CatalogSection.Live => (cache.LiveCategories, cache.LiveStreams),
            CatalogSection.Movies => (cache.VodCategories, cache.VodStreams),
            _ => (cache.SeriesCategories, cache.Series)
        };
        CatalogHeadingText.Text = titleOverride ?? (section == CatalogSection.Live ? "CANAIS AO VIVO" : section == CatalogSection.Movies ? "FILMES" : "SÉRIES");
        CatalogSearchBox.Text = string.Empty;
        CatalogCategoriesList.ItemsSource = forcedCategoryId is null ? _catalogCategories : _catalogCategories.Where(c => c.Id == forcedCategoryId).ToList();
        if (CatalogCategoriesList.Items.Count > 0) CatalogCategoriesList.SelectedIndex = 0;
        _catalogPage = 0;
        ApplyCatalogFilter();
        Navigate(Screen.Catalog);
        CatalogCategoriesList.Focus();
    }

    private void ApplyCatalogFilter()
    {
        var q = CatalogSearchBox.Text.Trim();
        if (!string.IsNullOrWhiteSpace(q))
            _catalogFiltered = _catalogAll.Where(x => x.Title.Contains(q, StringComparison.CurrentCultureIgnoreCase)).ToList();
        else
        {
            var id = (CatalogCategoriesList.SelectedItem as CategoryItem)?.Id ?? _forcedCategoryId ?? string.Empty;
            _catalogFiltered = string.IsNullOrWhiteSpace(id) ? new() : _catalogAll.Where(x => x.CategoryId == id).ToList();
        }
        _catalogPage = Math.Clamp(_catalogPage, 0, Math.Max(0, (_catalogFiltered.Count - 1) / PageSize));
        ShowCatalogPage();
    }

    private void ShowCatalogPage()
    {
        var totalPages = Math.Max(1, (int)Math.Ceiling(_catalogFiltered.Count / (double)PageSize));
        var items = _catalogFiltered.Skip(_catalogPage * PageSize).Take(PageSize).ToList();
        CatalogItemsControl.ItemsSource = items;
        CatalogCountText.Text = $"{_catalogFiltered.Count:N0} itens  •  página {_catalogPage + 1}/{totalPages}";
    }

    private void CatalogCategoriesList_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (string.IsNullOrWhiteSpace(CatalogSearchBox.Text)) { _catalogPage = 0; ApplyCatalogFilter(); }
    }
    private void CatalogSearchBox_TextChanged(object sender, TextChangedEventArgs e) { _catalogPage = 0; ApplyCatalogFilter(); }
    private void CatalogPrevPage_Click(object sender, RoutedEventArgs e) { if (_catalogPage > 0) { _catalogPage--; ShowCatalogPage(); } }
    private void CatalogNextPage_Click(object sender, RoutedEventArgs e) { if ((_catalogPage + 1) * PageSize < _catalogFiltered.Count) { _catalogPage++; ShowCatalogPage(); } }

    private async void CatalogItem_Click(object sender, RoutedEventArgs e)
    {
        if ((sender as Button)?.Tag is not StreamItem item || _activeProfile is null) return;
        try
        {
            _catalogClient ??= await CreateLoggedClientAsync();
            if (_catalogSection == CatalogSection.Live)
            {
                var ext = string.IsNullOrWhiteSpace(item.Extension) ? _catalogClient.LiveExtension : item.Extension;
                var req = new PlaybackRequest { Kind = "live", Id = item.Id, Title = item.Title, IconUrl = item.IconUrl, Extension = ext, Url = _catalogClient.StreamUrl("live", item.Id, ext) };
                var playlist = _catalogFiltered;
                var index = Math.Max(0, playlist.FindIndex(x => x.Id == item.Id));
                await OpenPlayerAsync(req, playlist, index);
            }
            else if (_catalogSection == CatalogSection.Movies)
            {
                _detailItem = item;
                DetailTitleText.Text = item.Title;
                DetailMetaText.Text = string.IsNullOrWhiteSpace(item.Rating) ? "FILME" : $"★ {item.Rating}";
                DetailPlotText.Text = string.IsNullOrWhiteSpace(item.Plot) ? "Sinopse não informada pelo serviço." : item.Plot;
                SetRemoteImage(DetailPosterImage, item.IconUrl);
                Navigate(Screen.Detail);
                _ = LoadMovieDetailsAsync(item);
            }
            else await OpenSeriesAsync(item);
        }
        catch (Exception ex) { CatalogCountText.Text = ex.Message; }
    }

    private async Task<XtreamClient> CreateLoggedClientAsync()
    {
        if (_activeProfile is null) throw new InvalidOperationException("Nenhuma lista ativa.");
        var c = new XtreamClient(_activeProfile.Dns, _activeProfile.Username, _services.Profiles.GetPassword(_activeProfile));
        await c.LoginAsync();
        return c;
    }

    // MOVIE DETAIL
    private async Task LoadMovieDetailsAsync(StreamItem item)
    {
        try
        {
            _catalogClient ??= await CreateLoggedClientAsync();
            var root = await _catalogClient.GetObjectAsync("get_vod_info", "vod_id", item.Id);
            var info = root["info"] as JsonObject;
            var data = root["movie_data"] as JsonObject;
            var plot = info is null ? string.Empty : XtreamClient.ReadString(info, "plot");
            if (string.IsNullOrWhiteSpace(plot) && info is not null) plot = XtreamClient.ReadString(info, "description");
            if (string.IsNullOrWhiteSpace(plot) && data is not null) plot = XtreamClient.ReadString(data, "plot");
            if (!string.IsNullOrWhiteSpace(plot)) DetailPlotText.Text = plot;
        }
        catch { }
    }

    private async void DetailPlay_Click(object sender, RoutedEventArgs e)
    {
        if (_detailItem is null) return;
        try
        {
            _catalogClient ??= await CreateLoggedClientAsync();
            var ext = string.IsNullOrWhiteSpace(_detailItem.Extension) ? "mp4" : _detailItem.Extension;
            var req = new PlaybackRequest { Kind = "movie", Id = _detailItem.Id, Title = _detailItem.Title, Subtitle = "Filme", IconUrl = _detailItem.IconUrl, Extension = ext, Url = _catalogClient.StreamUrl("movie", _detailItem.Id, ext) };
            await OpenPlayerAsync(req);
        }
        catch (Exception ex) { DetailPlotText.Text = ex.Message; }
    }

    // SERIES
    private async Task OpenSeriesAsync(StreamItem series)
    {
        _currentSeries = series;
        _seriesSeasons.Clear();
        SeriesTitleText.Text = series.Title;
        SeriesStatusText.Text = "Carregando temporadas e episódios…";
        SeasonsList.ItemsSource = null;
        EpisodesList.ItemsSource = null;
        Navigate(Screen.Series);
        SetBusy(true, "Carregando série…", series.Title);
        try
        {
            _seriesClient?.Dispose();
            _seriesClient = await CreateLoggedClientAsync();
            var root = await _seriesClient.GetObjectAsync("get_series_info", "series_id", series.Id);
            ParseEpisodes(root, series);
            SeasonsList.ItemsSource = _seriesSeasons.Keys.Select(n => n == 0 ? "Especiais" : $"Temporada {n}").ToList();
            if (SeasonsList.Items.Count > 0) SeasonsList.SelectedIndex = 0;
            SeriesStatusText.Text = _seriesSeasons.Count == 0 ? "O servidor não retornou episódios." : $"{_seriesSeasons.Sum(x => x.Value.Count)} episódios";
        }
        catch (Exception ex) { SeriesStatusText.Text = ex.Message; }
        finally { SetBusy(false); EpisodesList.Focus(); }
    }

    private void ParseEpisodes(JsonObject root, StreamItem series)
    {
        JsonNode? raw = root["episodes"];
        if (raw is null && root["data"] is JsonObject data) raw = data["episodes"];
        if (raw is JsonObject bySeason)
        {
            foreach (var kv in bySeason)
            {
                int.TryParse(kv.Key, out var season);
                if (kv.Value is JsonArray arr) AddEpisodes(season, arr, series);
            }
        }
        else if (raw is JsonArray flat) AddEpisodes(-1, flat, series);
    }

    private void AddEpisodes(int seasonHint, JsonArray array, StreamItem series)
    {
        foreach (var node in array)
        {
            if (node is not JsonObject obj) continue;
            var season = seasonHint >= 0 ? seasonHint : ParseInt(obj, "season", 0);
            var num = ParseInt(obj, "episode_num", ParseInt(obj, "episode", 0));
            var id = XtreamClient.ReadString(obj, "id");
            if (string.IsNullOrWhiteSpace(id)) id = XtreamClient.ReadString(obj, "stream_id");
            if (string.IsNullOrWhiteSpace(id)) continue;
            var title = XtreamClient.ReadString(obj, "title");
            if (string.IsNullOrWhiteSpace(title)) title = num > 0 ? $"Episódio {num}" : "Episódio";
            var ext = XtreamClient.ReadString(obj, "container_extension");
            var info = obj["info"] as JsonObject;
            var icon = info is null ? string.Empty : XtreamClient.ReadString(info, "movie_image");
            var plot = info is null ? string.Empty : XtreamClient.ReadString(info, "plot");
            if (!_seriesSeasons.TryGetValue(season, out var list)) _seriesSeasons[season] = list = new();
            list.Add(new EpisodeItem { Id = id, SeriesId = series.Id, SeriesTitle = series.Title, Title = title, Season = season, Episode = num, Extension = string.IsNullOrWhiteSpace(ext) ? "mp4" : ext, IconUrl = icon, Plot = plot });
        }
        foreach (var list in _seriesSeasons.Values) list.Sort((a, b) => a.Episode.CompareTo(b.Episode));
    }

    private static int ParseInt(JsonObject obj, string key, int fallback) => int.TryParse(XtreamClient.ReadString(obj, key), out var v) ? v : fallback;

    private void SeasonsList_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (SeasonsList.SelectedIndex < 0 || SeasonsList.SelectedIndex >= _seriesSeasons.Count) return;
        var season = _seriesSeasons.Keys.ElementAt(SeasonsList.SelectedIndex);
        EpisodesList.ItemsSource = _seriesSeasons[season];
        if (EpisodesList.Items.Count > 0) EpisodesList.SelectedIndex = 0;
    }

    private async Task PlaySelectedEpisodeAsync()
    {
        if (_seriesClient is null || EpisodesList.SelectedItem is not EpisodeItem ep) return;
        var req = new PlaybackRequest { Kind = "series", Id = ep.Id, ParentId = ep.SeriesId, Title = ep.SeriesTitle, Subtitle = ep.Season > 0 ? $"Temporada {ep.Season} • Episódio {ep.Episode}" : ep.Title, IconUrl = ep.IconUrl, Extension = ep.Extension, Url = _seriesClient.StreamUrl("series", ep.Id, ep.Extension) };
        await OpenPlayerAsync(req);
    }
    private async void EpisodesList_MouseDoubleClick(object sender, MouseButtonEventArgs e) => await PlaySelectedEpisodeAsync();
    private async void EpisodesList_KeyDown(object sender, KeyEventArgs e) { if (e.Key == Key.Enter) { e.Handled = true; await PlaySelectedEpisodeAsync(); } }

    // CONTINUE
    private async Task PlayContinueSelectedAsync()
    {
        if (ContinueList.SelectedItem is not ContinueRow row || _activeProfile is null) return;
        try
        {
            var client = await CreateLoggedClientAsync();
            var h = row.Entry;
            var ext = string.IsNullOrWhiteSpace(h.Extension) ? "mp4" : h.Extension;
            var req = new PlaybackRequest { Kind = h.Kind, Id = h.Id, ParentId = h.ParentId, Title = h.Title, Subtitle = h.Subtitle, IconUrl = h.IconUrl, Extension = ext, Url = client.StreamUrl(h.Kind, h.Id, ext) };
            client.Dispose();
            await OpenPlayerAsync(req);
        }
        catch { }
    }
    private async void ContinueList_MouseDoubleClick(object sender, MouseButtonEventArgs e) => await PlayContinueSelectedAsync();
    private async void ContinueList_KeyDown(object sender, KeyEventArgs e) { if (e.Key == Key.Enter) { e.Handled = true; await PlayContinueSelectedAsync(); } }

    // ACCOUNT
    private void LoadProfiles()
    {
        ProfilesList.ItemsSource = _services.Profiles.LoadProfiles();
        var all = (ProfilesList.ItemsSource as IEnumerable<Profile>)?.ToList() ?? new();
        if (_activeProfile is not null)
        {
            var idx = all.FindIndex(p => p.Id == _activeProfile.Id);
            if (idx >= 0) ProfilesList.SelectedIndex = idx;
        }
    }

    private void ProfilesList_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (ProfilesList.SelectedItem is not Profile p) return;
        AccountNameBox.Text = p.DisplayName;
        AccountUserBox.Text = p.Username;
        AccountDnsBox.Text = p.Dns;
        AccountPasswordBox.Password = _services.Profiles.GetPassword(p);
        AccountStatusText.Text = _activeProfile?.Id == p.Id ? "● ATIVA" : string.Empty;
    }

    private async void AccountConnect_Click(object sender, RoutedEventArgs e)
    {
        if (ProfilesList.SelectedItem is not Profile p) return;
        _services.Profiles.SetActive(p.Id);
        _activeProfile = p;
        ActiveListText.Text = $"LISTA ATIVA: {p.DisplayName}";
        AccountStatusText.Text = "Conectando…";
        await RefreshContentsAsync(false);
        AccountStatusText.Text = "● ATIVA";
    }

    private async void AccountSave_Click(object sender, RoutedEventArgs e)
    {
        var selected = ProfilesList.SelectedItem as Profile;
        var p = selected ?? new Profile();
        try
        {
            var dns = XtreamClient.NormalizeDns(AccountDnsBox.Text);
            var user = AccountUserBox.Text.Trim();
            var pass = AccountPasswordBox.Password;
            using var client = new XtreamClient(dns, user, pass);
            await client.LoginAsync();
            p.Name = string.IsNullOrWhiteSpace(AccountNameBox.Text) ? "Minha Lista" : AccountNameBox.Text.Trim();
            p.Username = user; p.Dns = dns;
            _services.Profiles.SaveProfile(p, pass);
            if (selected is null) _services.Profiles.SetActive(p.Id);
            _activeProfile = _services.Profiles.GetActiveProfile();
            LoadProfiles();
            AccountStatusText.Text = "Lista salva.";
        }
        catch (Exception ex) { AccountStatusText.Text = ex.Message; }
    }

    private void AccountDelete_Click(object sender, RoutedEventArgs e)
    {
        if (ProfilesList.SelectedItem is not Profile p) return;
        if (_activeProfile?.Id == p.Id) { AccountStatusText.Text = "Troque para outra lista antes de excluir a lista ativa."; return; }
        _services.Profiles.DeleteProfile(p.Id);
        LoadProfiles();
        AccountStatusText.Text = "Lista excluída.";
    }

    private async void AccountRefresh_Click(object sender, RoutedEventArgs e)
    {
        if (_activeProfile is null) return;
        AccountStatusText.Text = "Atualizando sua conta…";
        try
        {
            using var client = await CreateLoggedClientAsync();
            _accountInfo = client.AccountInfo;
            AccountStatusText.Text = "Conta atualizada.";
        }
        catch (Exception ex) { AccountStatusText.Text = ex.Message; }
    }

    private void AccountAdd_Click(object sender, RoutedEventArgs e)
    {
        ProfilesList.SelectedItem = null;
        AccountNameBox.Text = "Minha Lista";
        AccountUserBox.Text = string.Empty;
        AccountPasswordBox.Password = string.Empty;
        AccountDnsBox.Text = string.Empty;
        AccountNameBox.Focus();
        AccountStatusText.Text = "Preencha os dados e use SALVAR / EDITAR.";
    }

    // PLAYER - uma única instância VLC, evitando recriações pesadas
    private async Task OpenPlayerAsync(PlaybackRequest request, List<StreamItem>? playlist = null, int liveIndex = 0)
    {
        _playRequest = request;
        _livePlaylist = playlist ?? new();
        _liveIndex = Math.Clamp(liveIndex, 0, Math.Max(0, _livePlaylist.Count - 1));
        PlayerTitleText.Text = request.Title;
        PlayerSubtitleText.Text = request.Subtitle;
        VodProgressGrid.Visibility = request.IsLive ? Visibility.Collapsed : Visibility.Visible;
        LiveOverlay.Visibility = Visibility.Collapsed;
        PlayerErrorBorder.Visibility = Visibility.Collapsed;
        Navigate(Screen.Player);

        if (_libVlc is null)
        {
            _libVlc = new LibVLC("--network-caching=1200", "--file-caching=800", "--no-video-title-show");
            _mediaPlayer = new MediaPlayer(_libVlc);
            _mediaPlayer.EncounteredError += (_, _) => Dispatcher.Invoke(() => ShowPlayerError("O player encontrou um erro ao abrir este conteúdo."));
            _mediaPlayer.EndReached += (_, _) => Dispatcher.Invoke(() => SaveProgress(true));
            _mediaPlayer.Playing += (_, _) => Dispatcher.InvokeAsync(async () => { await Task.Delay(350); ApplyResumePosition(); });
            VideoView.MediaPlayer = _mediaPlayer;
        }

        if (request.IsLive && _livePlaylist.Count > 0 && _activeProfile is not null)
        {
            ChannelList.ItemsSource = _livePlaylist;
            ChannelList.SelectedIndex = _liveIndex;
            _liveClient?.Dispose();
            _liveClient = await CreateLoggedClientAsync();
        }
        PlayRequest(request);
        _playerUiTimer.Start();
        Focus();
    }

    private void PlayRequest(PlaybackRequest request)
    {
        if (_mediaPlayer is null || _libVlc is null) return;
        _playRequest = request;
        _resumeApplied = false;
        PlayerTitleText.Text = request.Title;
        PlayerSubtitleText.Text = request.Subtitle;
        _media?.Dispose();
        _media = new Media(_libVlc, request.Url, FromType.FromLocation);
        _media.AddOption(":network-caching=1200");
        if (!_mediaPlayer.Play(_media)) ShowPlayerError("O VLC não conseguiu iniciar esta transmissão.");
    }

    private void RefreshPlayerUi()
    {
        if (_mediaPlayer is null || _playRequest is null || _playRequest.IsLive) return;
        var len = Math.Max(0, _mediaPlayer.Length);
        var time = Math.Max(0, _mediaPlayer.Time);
        if (!_seeking) { PlayerProgressSlider.Maximum = Math.Max(1, len); PlayerProgressSlider.Value = Math.Min(time, PlayerProgressSlider.Maximum); }
        PlayerCurrentText.Text = FormatTime(time); PlayerDurationText.Text = FormatTime(len);
        if (time > 0) SaveProgress(false);
    }

    private static string FormatTime(long ms)
    {
        var t = TimeSpan.FromMilliseconds(Math.Max(0, ms));
        return t.TotalHours >= 1 ? $"{(int)t.TotalHours:00}:{t.Minutes:00}:{t.Seconds:00}" : $"{t.Minutes:00}:{t.Seconds:00}";
    }

    private void ApplyResumePosition()
    {
        if (_resumeApplied || _mediaPlayer is null || _playRequest is null || _playRequest.IsLive || _activeProfile is null) return;
        _resumeApplied = true;
        var old = _services.History.Get(_activeProfile.Id, HistoryStore.KeyFor(_playRequest));
        if (old is not null && !old.Completed && old.PositionMs > 10000 && old.DurationMs > 0 && old.PositionMs < old.DurationMs * .95) _mediaPlayer.Time = old.PositionMs;
    }

    private void SaveProgress(bool completed)
    {
        if (_mediaPlayer is null || _playRequest is null || _playRequest.IsLive || _activeProfile is null) return;
        _services.History.Save(_activeProfile.Id, _playRequest, Math.Max(0, _mediaPlayer.Time), Math.Max(0, _mediaPlayer.Length), completed);
    }

    private void ShowLiveOverlay()
    {
        if (_playRequest?.IsLive != true || _livePlaylist.Count == 0) return;
        LiveOverlay.Visibility = Visibility.Visible;
        ChannelList.SelectedIndex = _liveIndex;
        if (ChannelList.SelectedItem is not null) ChannelList.ScrollIntoView(ChannelList.SelectedItem);
        ChannelList.Focus();
        RestartOverlayTimer();
    }
    private void HideLiveOverlay() { _overlayTimer.Stop(); LiveOverlay.Visibility = Visibility.Collapsed; Focus(); }
    private void RestartOverlayTimer() { _overlayTimer.Stop(); _overlayTimer.Start(); }

    private void SwitchSelectedChannel()
    {
        if (ChannelList.SelectedItem is not StreamItem item || _liveClient is null) return;
        _liveIndex = Math.Max(0, ChannelList.SelectedIndex);
        var ext = string.IsNullOrWhiteSpace(item.Extension) ? _liveClient.LiveExtension : item.Extension;
        PlayRequest(new PlaybackRequest { Kind = "live", Id = item.Id, Title = item.Title, IconUrl = item.IconUrl, Extension = ext, Url = _liveClient.StreamUrl("live", item.Id, ext) });
        RestartOverlayTimer();
    }

    private void PlayerProgressSlider_PreviewMouseDown(object sender, MouseButtonEventArgs e) => _seeking = true;
    private void PlayerProgressSlider_PreviewMouseUp(object sender, MouseButtonEventArgs e) { if (_mediaPlayer is not null) _mediaPlayer.Time = (long)PlayerProgressSlider.Value; _seeking = false; }
    private void ChannelList_MouseDoubleClick(object sender, MouseButtonEventArgs e) => SwitchSelectedChannel();
    private void ShowPlayerError(string text) { PlayerErrorText.Text = text; PlayerErrorBorder.Visibility = Visibility.Visible; }

    private void StopPlayback()
    {
        try { SaveProgress(false); } catch { }
        _overlayTimer.Stop(); _playerUiTimer.Stop();
        try { _mediaPlayer?.Stop(); } catch { }
        _media?.Dispose(); _media = null;
        _liveClient?.Dispose(); _liveClient = null;
        LiveOverlay.Visibility = Visibility.Collapsed;
    }

    // NAVIGATION / KEYBOARD
    private void Back_Click(object sender, RoutedEventArgs e) => GoBack();

    private void Window_PreviewKeyDown(object sender, KeyEventArgs e)
    {
        if (_busy) return;
        if (ExitOverlay.Visibility == Visibility.Visible)
        {
            if (e.Key == Key.Escape) { ExitOverlay.Visibility = Visibility.Collapsed; e.Handled = true; }
            return;
        }
        if (e.Key == Key.F11)
        {
            WindowStyle = WindowStyle == WindowStyle.None ? WindowStyle.SingleBorderWindow : WindowStyle.None;
            WindowState = WindowState.Maximized;
            e.Handled = true; return;
        }
        if (_screen == Screen.Player && _playRequest is not null)
        {
            if (e.Key == Key.Escape)
            {
                if (LiveOverlay.Visibility == Visibility.Visible) HideLiveOverlay(); else GoBack();
                e.Handled = true; return;
            }
            if (_playRequest.IsLive)
            {
                if (e.Key == Key.Enter)
                {
                    if (LiveOverlay.Visibility == Visibility.Visible) SwitchSelectedChannel(); else ShowLiveOverlay();
                    e.Handled = true; return;
                }
                if (LiveOverlay.Visibility == Visibility.Visible && e.Key is Key.Up or Key.Down or Key.Left or Key.Right) RestartOverlayTimer();
            }
            else if (_mediaPlayer is not null)
            {
                if (e.Key == Key.Right) { _mediaPlayer.Time = Math.Min(_mediaPlayer.Length, _mediaPlayer.Time + 15000); e.Handled = true; }
                else if (e.Key == Key.Left) { _mediaPlayer.Time = Math.Max(0, _mediaPlayer.Time - 15000); e.Handled = true; }
                else if (e.Key == Key.Space) { _mediaPlayer.SetPause(_mediaPlayer.IsPlaying); e.Handled = true; }
            }
            return;
        }
        if (e.Key == Key.Escape)
        {
            if (_screen == Screen.Home) ShowExit(); else GoBack();
            e.Handled = true;
        }
    }

    private void Window_MouseMove(object sender, MouseEventArgs e)
    {
        if (_screen == Screen.Player && LiveOverlay.Visibility == Visibility.Visible) RestartOverlayTimer();
    }

    private void ShowExit() { ExitOverlay.Visibility = Visibility.Visible; ExitNoButton.Focus(); }
    private void ExitNo_Click(object sender, RoutedEventArgs e) { ExitOverlay.Visibility = Visibility.Collapsed; LiveButton.Focus(); }
    private void ExitYes_Click(object sender, RoutedEventArgs e) => Close();

    private static void SetRemoteImage(Image image, string url)
    {
        image.Source = null;
        if (string.IsNullOrWhiteSpace(url)) return;
        try
        {
            var bmp = new BitmapImage();
            bmp.BeginInit(); bmp.UriSource = new Uri(url, UriKind.Absolute); bmp.CacheOption = BitmapCacheOption.OnLoad; bmp.CreateOptions = BitmapCreateOptions.IgnoreImageCache; bmp.EndInit();
            image.Source = bmp;
        }
        catch { }
    }

    private void MainWindow_Closed(object? sender, EventArgs e)
    {
        _clock.Stop(); _playerUiTimer.Stop(); _overlayTimer.Stop();
        try { _mediaPlayer?.Stop(); } catch { }
        _media?.Dispose(); _mediaPlayer?.Dispose(); _libVlc?.Dispose();
        _catalogClient?.Dispose(); _seriesClient?.Dispose(); _liveClient?.Dispose();
    }

    private sealed class ContinueRow
    {
        public HistoryEntry Entry { get; }
        public ContinueRow(HistoryEntry entry) => Entry = entry;
        public string Title => Entry.Title;
        public string Subtitle => Entry.Subtitle;
        public double ProgressPercent => Entry.DurationMs <= 0 ? 0 : Math.Clamp(Entry.PositionMs * 100d / Entry.DurationMs, 0, 100);
    }
}
