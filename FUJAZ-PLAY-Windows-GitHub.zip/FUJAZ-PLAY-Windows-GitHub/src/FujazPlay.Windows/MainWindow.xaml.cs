using System.Diagnostics;
using System.Globalization;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;
using FujazPlay.Windows.Models;
using FujazPlay.Windows.Services;
using FujazPlay.Windows.Views;

namespace FujazPlay.Windows;

public partial class MainWindow : Window
{
    private readonly AppServices _services;
    private readonly DispatcherTimer _clock = new() { Interval = TimeSpan.FromSeconds(1) };
    private Profile? _activeProfile;
    private AccountInfo? _accountInfo;
    private bool _busy;

    public MainWindow() : this(new AppServices(), null) { }

    public MainWindow(AppServices services, Profile? activeProfile = null)
    {
        _services = services;
        _activeProfile = activeProfile;
        InitializeComponent();
        _clock.Tick += (_, _) => UpdateClock();
        _clock.Start();
        UpdateClock();
        Loaded += MainWindow_Loaded;
    }

    private async void MainWindow_Loaded(object sender, RoutedEventArgs e)
    {
        _activeProfile ??= _services.Profiles.GetActiveProfile();
        if (_activeProfile is null)
        {
            Close();
            return;
        }
        await RefreshContentsAsync(firstOpen: true);
        LiveButton.Focus();
    }

    private void UpdateClock()
    {
        var now = DateTime.Now;
        ClockText.Text = now.ToString("HH:mm");
        SecondsText.Text = now.ToString("ss");
        DateText.Text = now.ToString("ddd, dd MMM", new CultureInfo("pt-BR"));
    }

    private void SetBusy(bool value, string title = "Atualizando conteúdos…", string message = "")
    {
        _busy = value;
        BusyBorder.Visibility = value ? Visibility.Visible : Visibility.Collapsed;
        BusyTitle.Text = title;
        BusyMessage.Text = message;
        LiveButton.IsEnabled = FootballButton.IsEnabled = MoviesButton.IsEnabled = SeriesButton.IsEnabled = RefreshButton.IsEnabled = !value;
    }

    private async Task RefreshContentsAsync(bool firstOpen = false)
    {
        if (_activeProfile is null || _busy) return;
        var progress = new Progress<string>(text => BusyMessage.Text = text);
        SetBusy(true, firstOpen ? "Preparando o FUJAZ PLAY…" : "Atualizando conteúdos…", "Conectando à lista ativa…");
        try
        {
            var result = await _services.Content.RefreshAsync(_activeProfile, progress);
            _accountInfo = result.Account;
            ActiveListText.Text = $"LISTA ATIVA: {_activeProfile.DisplayName}";
            StatusText.Text = $"Conteúdos atualizados • {DateTime.Now:HH:mm}";
        }
        catch (Exception ex)
        {
            var cached = _services.Content.TryGet(_activeProfile);
            if (cached is not null)
            {
                StatusText.Text = "Servidor não respondeu agora • usando conteúdo salvo";
                MessageBox.Show(this, ex.Message + "\n\nO FUJAZ PLAY vai usar o conteúdo salvo anteriormente.", "FUJAZ PLAY", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            else
            {
                MessageBox.Show(this, ex.Message, "Não foi possível atualizar", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        finally { SetBusy(false); }
    }

    private ContentCache? CacheOrWarn()
    {
        if (_activeProfile is null) return null;
        var cache = _services.Content.TryGet(_activeProfile);
        if (cache is null) MessageBox.Show(this, "Ainda não há conteúdo carregado. Use ATUALIZAR CONTEÚDOS.", "FUJAZ PLAY");
        return cache;
    }

    private void Live_Click(object sender, RoutedEventArgs e)
    {
        var cache = CacheOrWarn(); if (cache is null || _activeProfile is null) return;
        new CatalogWindow(_services, _activeProfile, CatalogSection.Live, cache).ShowDialog();
    }

    private void Movies_Click(object sender, RoutedEventArgs e)
    {
        var cache = CacheOrWarn(); if (cache is null || _activeProfile is null) return;
        new CatalogWindow(_services, _activeProfile, CatalogSection.Movies, cache).ShowDialog();
    }

    private void Series_Click(object sender, RoutedEventArgs e)
    {
        var cache = CacheOrWarn(); if (cache is null || _activeProfile is null) return;
        new CatalogWindow(_services, _activeProfile, CatalogSection.Series, cache).ShowDialog();
    }

    private void Football_Click(object sender, RoutedEventArgs e)
    {
        var cache = CacheOrWarn(); if (cache is null || _activeProfile is null) return;
        var category = ContentService.FindFootballCategory(cache.LiveCategories);
        if (category is null)
        {
            MessageBox.Show(this, "Não encontrei uma categoria com Jogos de Hoje, Jogos do Dia, Jogos ou Futebol nesta lista.", "Futebol");
            return;
        }
        new CatalogWindow(_services, _activeProfile, CatalogSection.Live, cache, category.Id, "FUTEBOL").ShowDialog();
    }

    private void Continue_Click(object sender, RoutedEventArgs e)
    {
        if (_activeProfile is null) return;
        new ContinueWindow(_services, _activeProfile) { Owner = this }.ShowDialog();
    }

    private void Wifi_Click(object sender, RoutedEventArgs e)
    {
        try { Process.Start(new ProcessStartInfo("ms-settings:network-wifi") { UseShellExecute = true }); }
        catch { Process.Start(new ProcessStartInfo("ms-settings:network") { UseShellExecute = true }); }
    }

    private void Account_Click(object sender, RoutedEventArgs e)
    {
        var oldId = _activeProfile?.Id;
        var window = new AccountWindow(_services, _activeProfile, _accountInfo) { Owner = this };
        window.ShowDialog();
        _activeProfile = _services.Profiles.GetActiveProfile();
        if (_activeProfile is null) return;
        ActiveListText.Text = $"LISTA ATIVA: {_activeProfile.DisplayName}";
        if (oldId != _activeProfile.Id) _ = RefreshContentsAsync(firstOpen: false);
    }

    private async void Refresh_Click(object sender, RoutedEventArgs e) => await RefreshContentsAsync(false);

    private void Window_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Escape && !_busy) Close();
        if (e.Key == Key.F11)
        {
            WindowStyle = WindowStyle == WindowStyle.None ? WindowStyle.SingleBorderWindow : WindowStyle.None;
            WindowState = WindowState.Maximized;
        }
    }
}
