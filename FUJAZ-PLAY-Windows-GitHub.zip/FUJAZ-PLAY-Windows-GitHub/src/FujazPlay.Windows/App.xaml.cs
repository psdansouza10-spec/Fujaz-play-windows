using System.IO;
using System.Windows;
using System.Windows.Threading;
using FujazPlay.Windows.Services;
using LibVLCSharp.Shared;

namespace FujazPlay.Windows;

public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        DispatcherUnhandledException += App_DispatcherUnhandledException;
        AppDomain.CurrentDomain.UnhandledException += CurrentDomain_UnhandledException;
        try { Core.Initialize(); } catch { }
        try
        {
            base.OnStartup(e);
            var services = new AppServices();
            var main = new MainWindow(services, services.Profiles.GetActiveProfile());
            MainWindow = main;
            ShutdownMode = ShutdownMode.OnMainWindowClose;
            main.Show();
        }
        catch (Exception ex)
        {
            ShowFatalError(ex);
            Shutdown(-1);
        }
    }

    private void App_DispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
    {
        ShowFatalError(e.Exception);
        e.Handled = true;
    }

    private void CurrentDomain_UnhandledException(object? sender, UnhandledExceptionEventArgs e)
    {
        if (e.ExceptionObject is Exception ex) WriteLog(ex);
    }

    private static void ShowFatalError(Exception ex)
    {
        WriteLog(ex);
        MessageBox.Show($"O FUJAZ PLAY encontrou um erro.\n\n{ex.Message}\n\nDiagnóstico: %LOCALAPPDATA%\\FUJAZ PLAY\\startup-error.txt", "FUJAZ PLAY", MessageBoxButton.OK, MessageBoxImage.Error);
    }

    private static void WriteLog(Exception ex)
    {
        try
        {
            var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "FUJAZ PLAY");
            Directory.CreateDirectory(dir);
            File.WriteAllText(Path.Combine(dir, "startup-error.txt"), ex.ToString());
        }
        catch { }
    }
}
