using System.Windows;
using LibVLCSharp.Shared;

namespace FujazPlay.Windows;

public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        try { Core.Initialize(); } catch { }
        base.OnStartup(e);
    }
}
