using System;
using System.IO;
using System.Windows;
using System.Windows.Threading;
using FujazPlay.Windows.Services;
using FujazPlay.Windows.Views;
using LibVLCSharp.Shared;

namespace FujazPlay.Windows;

public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        DispatcherUnhandledException += App_DispatcherUnhandledException;
        AppDomain.CurrentDomain.UnhandledException += CurrentDomain_UnhandledException;

        try
        {
            Core.Initialize();
        }
        catch
        {
            // O player pode inicializar mais tarde; não bloqueia a abertura do app.
        }

        try
        {
            base.OnStartup(e);
            ShutdownMode = ShutdownMode.OnExplicitShutdown;

            var services = new AppServices();
            var activeProfile = services.Profiles.GetActiveProfile();

            if (activeProfile is null)
            {
                var login = new LoginWindow(services, initialLogin: true);
                var result = login.ShowDialog();
                if (result != true || login.SavedProfile is null)
                {
                    Shutdown(0);
                    return;
                }
                activeProfile = login.SavedProfile;
            }

            var main = new MainWindow(services, activeProfile);
            MainWindow = main;
            ShutdownMode = ShutdownMode.OnMainWindowClose;
            main.Show();
        }
        catch (Exception ex)
        {
            ShowFatalError(ex);
            Shutdown(-1);
        }
    }

    private void App_DispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
    {
        ShowFatalError(e.Exception);
        e.Handled = true;
    }

    private void CurrentDomain_UnhandledException(object? sender, UnhandledExceptionEventArgs e)
    {
        if (e.ExceptionObject is Exception ex)
            WriteLog(ex);
    }

    private static void ShowFatalError(Exception ex)
    {
        WriteLog(ex);
        MessageBox.Show(
            $"O FUJAZ PLAY encontrou um erro ao iniciar.\n\n{ex.Message}\n\nUm arquivo de diagnóstico foi salvo em %LOCALAPPDATA%\\FUJAZ PLAY\\startup-error.txt",
            "FUJAZ PLAY - Erro ao iniciar",
            MessageBoxButton.OK,
            MessageBoxImage.Error);
    }

    private static void WriteLog(Exception ex)
    {
        try
        {
            var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "FUJAZ PLAY");
            Directory.CreateDirectory(dir);
            File.WriteAllText(Path.Combine(dir, "startup-error.txt"), ex.ToString());
        }
        catch { }
    }
}
