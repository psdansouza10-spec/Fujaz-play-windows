using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using FujazPlay.Windows.Models;

namespace FujazPlay.Windows.Services;

public sealed class ProfileStore
{
    private readonly string _root;
    private readonly string _profilesPath;
    private readonly string _activePath;
    private static readonly byte[] Entropy = Encoding.UTF8.GetBytes("FUJAZ-PLAY-WINDOWS-v1");

    public ProfileStore()
    {
        _root = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "FujazPlay");
        Directory.CreateDirectory(_root);
        _profilesPath = Path.Combine(_root, "profiles.json");
        _activePath = Path.Combine(_root, "active.txt");
    }

    public IReadOnlyList<Profile> LoadProfiles()
    {
        try
        {
            if (!File.Exists(_profilesPath)) return Array.Empty<Profile>();
            return JsonSerializer.Deserialize<List<Profile>>(File.ReadAllText(_profilesPath), JsonOptions()) ?? new List<Profile>();
        }
        catch { return Array.Empty<Profile>(); }
    }

    public Profile? GetActiveProfile()
    {
        var all = LoadProfiles();
        if (all.Count == 0) return null;
        try
        {
            var id = File.Exists(_activePath) ? File.ReadAllText(_activePath).Trim() : string.Empty;
            return all.FirstOrDefault(p => p.Id == id) ?? all[0];
        }
        catch { return all[0]; }
    }

    public void SetActive(string id) => File.WriteAllText(_activePath, id ?? string.Empty);

    public void SaveProfile(Profile profile, string plainPassword)
    {
        var all = LoadProfiles().ToList();
        profile.Name = string.IsNullOrWhiteSpace(profile.Name) ? "Minha Lista" : profile.Name.Trim();
        profile.Dns = profile.Dns.Trim();
        profile.Username = profile.Username.Trim();
        profile.PasswordProtected = Protect(plainPassword);
        profile.UpdatedAt = DateTimeOffset.UtcNow.ToUnixTimeSeconds();

        var index = all.FindIndex(p => p.Id == profile.Id);
        if (index >= 0) all[index] = profile; else all.Add(profile);
        File.WriteAllText(_profilesPath, JsonSerializer.Serialize(all, JsonOptions()));
        if (!File.Exists(_activePath)) SetActive(profile.Id);
    }

    public void DeleteProfile(string id)
    {
        var all = LoadProfiles().Where(p => p.Id != id).ToList();
        File.WriteAllText(_profilesPath, JsonSerializer.Serialize(all, JsonOptions()));
        var active = GetActiveProfile();
        if (active is null && all.Count > 0) SetActive(all[0].Id);
    }

    public string GetPassword(Profile profile)
    {
        if (string.IsNullOrWhiteSpace(profile.PasswordProtected)) return string.Empty;
        try
        {
            var bytes = Convert.FromBase64String(profile.PasswordProtected);
            var clear = ProtectedData.Unprotect(bytes, Entropy, DataProtectionScope.CurrentUser);
            return Encoding.UTF8.GetString(clear);
        }
        catch { return string.Empty; }
    }

    private static string Protect(string value)
    {
        var clear = Encoding.UTF8.GetBytes(value ?? string.Empty);
        return Convert.ToBase64String(ProtectedData.Protect(clear, Entropy, DataProtectionScope.CurrentUser));
    }

    private static JsonSerializerOptions JsonOptions() => new() { WriteIndented = true, PropertyNameCaseInsensitive = true };
}
