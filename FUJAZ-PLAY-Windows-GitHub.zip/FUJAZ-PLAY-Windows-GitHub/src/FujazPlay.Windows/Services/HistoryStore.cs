using System.Text.Json;
using FujazPlay.Windows.Models;

namespace FujazPlay.Windows.Services;

public sealed class HistoryStore
{
    private readonly string _root;
    private readonly object _gate = new();

    public HistoryStore()
    {
        _root = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "FujazPlay", "history");
        Directory.CreateDirectory(_root);
    }

    public List<HistoryEntry> Load(string profileId)
    {
        lock (_gate)
        {
            try
            {
                var path = PathFor(profileId);
                if (!File.Exists(path)) return new();
                return JsonSerializer.Deserialize<List<HistoryEntry>>(File.ReadAllText(path)) ?? new();
            }
            catch { return new(); }
        }
    }

    public List<HistoryEntry> ContinueWatching(string profileId) => Load(profileId)
        .Where(x => !x.Completed && x.PositionMs > 0)
        .OrderByDescending(x => x.UpdatedAt)
        .Take(100)
        .ToList();

    public HistoryEntry? Get(string profileId, string key) => Load(profileId).FirstOrDefault(x => x.Key == key);

    public void Save(string profileId, PlaybackRequest request, long positionMs, long durationMs, bool completed)
    {
        if (request.IsLive) return;
        lock (_gate)
        {
            var all = Load(profileId);
            var key = KeyFor(request);
            var old = all.FirstOrDefault(x => x.Key == key);
            if (old is not null) all.Remove(old);
            var finalCompleted = completed || (durationMs > 0 && positionMs >= durationMs * 0.95);
            all.Insert(0, new HistoryEntry
            {
                Key = key,
                Kind = request.Kind,
                Id = request.Id,
                ParentId = request.ParentId,
                Title = request.Title,
                Subtitle = request.Subtitle,
                IconUrl = request.IconUrl,
                Extension = request.Extension,
                PositionMs = finalCompleted && durationMs > 0 ? durationMs : Math.Max(0, positionMs),
                DurationMs = Math.Max(0, durationMs),
                Completed = finalCompleted,
                UpdatedAt = DateTimeOffset.UtcNow.ToUnixTimeSeconds()
            });
            all = all.Take(500).ToList();
            try { File.WriteAllText(PathFor(profileId), JsonSerializer.Serialize(all)); } catch { }
        }
    }

    public static string KeyFor(PlaybackRequest request) => $"{request.Kind}:{request.ParentId}:{request.Id}";
    private string PathFor(string profileId) => Path.Combine(_root, profileId + ".json");
}
