using System.IO;
using System.Text.Json;
using System.Text.Json.Nodes;
using FujazPlay.Windows.Models;

namespace FujazPlay.Windows.Services;

public sealed class ContentService
{
    private readonly ProfileStore _profiles;
    private readonly string _cacheRoot;
    private readonly Dictionary<string, ContentCache> _memory = new();

    public ContentService(ProfileStore profiles)
    {
        _profiles = profiles;
        _cacheRoot = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "FujazPlay", "cache");
        Directory.CreateDirectory(_cacheRoot);
    }

    public ContentCache? TryGet(Profile profile)
    {
        if (_memory.TryGetValue(profile.Id, out var cached)) return cached;
        var path = CachePath(profile.Id);
        try
        {
            if (!File.Exists(path)) return null;
            cached = JsonSerializer.Deserialize<ContentCache>(File.ReadAllText(path), JsonOptions());
            if (cached is not null) _memory[profile.Id] = cached;
            return cached;
        }
        catch { return null; }
    }

    public async Task<(ContentCache Cache, AccountInfo Account)> RefreshAsync(Profile profile, IProgress<string>? progress = null, CancellationToken ct = default)
    {
        using var client = new XtreamClient(profile.Dns, profile.Username, _profiles.GetPassword(profile));
        progress?.Report("Conectando à lista…");
        var account = await client.LoginAsync(ct);

        var old = TryGet(profile) ?? new ContentCache();
        progress?.Report("Atualizando canais, filmes e séries…");

        var liveCatsTask = FetchSafe(() => client.GetArrayAsync("get_live_categories", ct: ct), old.LiveCategories, ParseCategories);
        var liveTask = FetchSafe(() => client.GetArrayAsync("get_live_streams", ct: ct), old.LiveStreams, a => ParseStreams(a, "live"));
        var vodCatsTask = FetchSafe(() => client.GetArrayAsync("get_vod_categories", ct: ct), old.VodCategories, ParseCategories);
        var vodTask = FetchSafe(() => client.GetArrayAsync("get_vod_streams", ct: ct), old.VodStreams, a => ParseStreams(a, "movie"));
        var seriesCatsTask = FetchSafe(() => client.GetArrayAsync("get_series_categories", ct: ct), old.SeriesCategories, ParseCategories);
        var seriesTask = FetchSafe(() => client.GetArrayAsync("get_series", ct: ct), old.Series, a => ParseStreams(a, "series"));

        await Task.WhenAll(liveCatsTask, liveTask, vodCatsTask, vodTask, seriesCatsTask, seriesTask).ConfigureAwait(false);

        var cache = new ContentCache
        {
            LiveCategories = liveCatsTask.Result,
            LiveStreams = liveTask.Result,
            VodCategories = vodCatsTask.Result,
            VodStreams = vodTask.Result,
            SeriesCategories = seriesCatsTask.Result,
            Series = seriesTask.Result,
            UpdatedAt = DateTimeOffset.UtcNow.ToUnixTimeSeconds()
        };

        _memory[profile.Id] = cache;
        try { await File.WriteAllTextAsync(CachePath(profile.Id), JsonSerializer.Serialize(cache, JsonOptions()), ct).ConfigureAwait(false); } catch { }
        progress?.Report("Conteúdos atualizados.");
        return (cache, account);
    }

    private static async Task<List<T>> FetchSafe<T>(Func<Task<JsonArray>> loader, List<T> fallback, Func<JsonArray, List<T>> parser)
    {
        try { return parser(await loader().ConfigureAwait(false)); }
        catch { return fallback.Count > 0 ? fallback : new List<T>(); }
    }

    public static List<CategoryItem> ParseCategories(JsonArray array)
    {
        var list = new List<CategoryItem>();
        foreach (var node in array)
        {
            if (node is not JsonObject obj) continue;
            var id = XtreamClient.ReadString(obj, "category_id");
            var name = XtreamClient.ReadString(obj, "category_name");
            if (!string.IsNullOrWhiteSpace(id) && !string.IsNullOrWhiteSpace(name)) list.Add(new CategoryItem { Id = id, Name = name.Trim() });
        }
        return list;
    }

    public static List<StreamItem> ParseStreams(JsonArray array, string kind)
    {
        var list = new List<StreamItem>();
        foreach (var node in array)
        {
            if (node is not JsonObject obj) continue;
            var id = kind == "series" ? XtreamClient.ReadString(obj, "series_id") : XtreamClient.ReadString(obj, "stream_id");
            var title = XtreamClient.ReadString(obj, "name");
            if (string.IsNullOrWhiteSpace(id) || string.IsNullOrWhiteSpace(title)) continue;
            var icon = kind == "series" ? XtreamClient.ReadString(obj, "cover") : XtreamClient.ReadString(obj, "stream_icon");
            var addedText = XtreamClient.ReadString(obj, "added");
            long.TryParse(addedText, out var added);
            list.Add(new StreamItem
            {
                Kind = kind,
                Id = id,
                Title = title.Trim(),
                CategoryId = XtreamClient.ReadString(obj, "category_id"),
                IconUrl = icon,
                Extension = XtreamClient.ReadString(obj, "container_extension"),
                Plot = XtreamClient.ReadString(obj, "plot"),
                Rating = XtreamClient.ReadString(obj, "rating"),
                EpgChannelId = XtreamClient.ReadString(obj, "epg_channel_id"),
                Added = added
            });
        }
        return list;
    }

    public static CategoryItem? FindFootballCategory(IEnumerable<CategoryItem> categories)
    {
        var list = categories.ToList();
        string Normalize(string s) => new string(s.Normalize(System.Text.NormalizationForm.FormD).Where(c => System.Globalization.CharUnicodeInfo.GetUnicodeCategory(c) != System.Globalization.UnicodeCategory.NonSpacingMark).ToArray()).ToLowerInvariant();
        var priorities = new[] { "jogos de hoje", "jogos do dia", "jogos", "futebol ao vivo", "futebol" };
        foreach (var term in priorities)
        {
            var exact = list.FirstOrDefault(c => Normalize(c.Name) == term);
            if (exact is not null) return exact;
            var contains = list.FirstOrDefault(c => Normalize(c.Name).Contains(term, StringComparison.Ordinal));
            if (contains is not null) return contains;
        }
        return null;
    }

    private string CachePath(string id) => Path.Combine(_cacheRoot, $"{id}.json");
    private static JsonSerializerOptions JsonOptions() => new() { WriteIndented = false, PropertyNameCaseInsensitive = true };
}
