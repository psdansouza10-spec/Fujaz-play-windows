namespace FujazPlay.Windows.Services;

public sealed class AppServices
{
    public ProfileStore Profiles { get; } = new();
    public ContentService Content { get; }
    public HistoryStore History { get; } = new();

    public AppServices() => Content = new ContentService(Profiles);
}
