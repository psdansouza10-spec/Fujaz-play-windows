using System.Net;
using System.Net.Http.Headers;
using System.Text.Json;
using System.Text.Json.Nodes;
using FujazPlay.Windows.Models;

namespace FujazPlay.Windows.Services;

public sealed class XtreamClient : IDisposable
{
    private readonly HttpClient _http;
    public string BaseUrl { get; }
    public string Username { get; }
    public string Password { get; }
    public string LiveExtension { get; private set; } = "m3u8";
    public AccountInfo AccountInfo { get; private set; } = new();

    public XtreamClient(string dns, string username, string password)
    {
        BaseUrl = NormalizeDns(dns);
        Username = username?.Trim() ?? string.Empty;
        Password = password ?? string.Empty;
        if (string.IsNullOrWhiteSpace(Username) || string.IsNullOrWhiteSpace(Password))
            throw new InvalidOperationException("Preencha usuário e senha.");

        var handler = new HttpClientHandler
        {
            AllowAutoRedirect = true,
            AutomaticDecompression = DecompressionMethods.All
        };
        _http = new HttpClient(handler) { Timeout = TimeSpan.FromSeconds(30) };
        _http.DefaultRequestHeaders.UserAgent.ParseAdd("FUJAZ-Play-Windows/1.0");
        _http.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
    }

    public static string NormalizeDns(string input)
    {
        var s = (input ?? string.Empty).Trim();
        if (string.IsNullOrWhiteSpace(s)) throw new InvalidOperationException("Preencha o DNS do seu serviço.");
        if (!s.Contains("://", StringComparison.Ordinal)) s = "https://" + s;
        if (!Uri.TryCreate(s, UriKind.Absolute, out var uri) || (uri.Scheme != Uri.UriSchemeHttp && uri.Scheme != Uri.UriSchemeHttps))
            throw new InvalidOperationException("DNS inválido. Use http://servidor:porta ou https://servidor.");

        var path = uri.AbsolutePath.TrimEnd('/');
        if (path.EndsWith("/player_api.php", StringComparison.OrdinalIgnoreCase) || path.EndsWith("/get.php", StringComparison.OrdinalIgnoreCase))
            path = path[..path.LastIndexOf('/')];

        var authority = uri.IsDefaultPort ? uri.Host : $"{uri.Host}:{uri.Port}";
        return $"{uri.Scheme}://{authority}{path}".TrimEnd('/');
    }

    private string ApiUrl(string? action = null, string? key = null, string? value = null)
    {
        var url = $"{BaseUrl}/player_api.php?username={Uri.EscapeDataString(Username)}&password={Uri.EscapeDataString(Password)}";
        if (!string.IsNullOrWhiteSpace(action)) url += "&action=" + Uri.EscapeDataString(action);
        if (!string.IsNullOrWhiteSpace(key) && value is not null) url += $"&{Uri.EscapeDataString(key)}={Uri.EscapeDataString(value)}";
        return url;
    }

    private async Task<JsonNode> RequestAsync(string? action = null, string? key = null, string? value = null, CancellationToken ct = default)
    {
        using var response = await _http.GetAsync(ApiUrl(action, key, value), HttpCompletionOption.ResponseHeadersRead, ct);
        if (response.StatusCode is HttpStatusCode.Unauthorized or HttpStatusCode.Forbidden)
            throw new InvalidOperationException("Acesso recusado. Confira usuário, senha e situação da conta.");
        if (!response.IsSuccessStatusCode)
            throw new InvalidOperationException($"O servidor respondeu HTTP {(int)response.StatusCode}.");

        var raw = (await response.Content.ReadAsStringAsync(ct)).Trim().TrimStart('\uFEFF');
        if (string.IsNullOrWhiteSpace(raw)) throw new InvalidOperationException("O servidor retornou uma resposta vazia.");
        try { return JsonNode.Parse(raw) ?? throw new InvalidOperationException("Resposta vazia."); }
        catch (JsonException) { throw new InvalidOperationException("O DNS não retornou uma lista compatível com Xtream Codes."); }
    }

    public async Task<AccountInfo> LoginAsync(CancellationToken ct = default)
    {
        var root = await RequestAsync(ct: ct) as JsonObject ?? throw new InvalidOperationException("Resposta de login inválida.");
        var info = root["user_info"] as JsonObject ?? throw new InvalidOperationException("O servidor não retornou os dados da conta.");
        var auth = ReadString(info, "auth");
        if (auth != "1" && !string.Equals(auth, "true", StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("Usuário ou senha não aceitos pelo servidor.");

        var status = ReadString(info, "status");
        if (!string.IsNullOrWhiteSpace(status) && !status.Equals("Active", StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("A conta não está ativa. Confira com o seu serviço.");

        var formats = info["allowed_output_formats"] as JsonArray;
        var hasHls = formats?.Any(v => string.Equals(v?.ToString(), "m3u8", StringComparison.OrdinalIgnoreCase)) == true;
        var hasTs = formats?.Any(v => string.Equals(v?.ToString(), "ts", StringComparison.OrdinalIgnoreCase)) == true;
        LiveExtension = !hasHls && hasTs ? "ts" : "m3u8";

        AccountInfo = new AccountInfo
        {
            Status = status,
            ExpDate = ReadString(info, "exp_date"),
            MaxConnections = ReadString(info, "max_connections"),
            ActiveConnections = ReadString(info, "active_cons"),
            LiveExtension = LiveExtension
        };
        return AccountInfo;
    }

    public async Task<JsonArray> GetArrayAsync(string action, string? key = null, string? value = null, CancellationToken ct = default)
    {
        var node = await RequestAsync(action, key, value, ct);
        if (node is JsonArray array) return array;
        if (node is JsonObject obj && obj.Count == 0) return new JsonArray();
        throw new InvalidOperationException("O servidor não enviou uma lista válida para esta seção.");
    }

    public async Task<JsonObject> GetObjectAsync(string action, string key, string value, CancellationToken ct = default)
    {
        var node = await RequestAsync(action, key, value, ct);
        if (node is JsonObject obj) return obj;
        if (node is JsonArray arr && arr.Count == 1 && arr[0] is JsonObject one) return one;
        throw new InvalidOperationException("O servidor não enviou os detalhes deste título.");
    }

    public string StreamUrl(string kind, string id, string? extension)
    {
        if (kind is not ("live" or "movie" or "series")) throw new InvalidOperationException("Tipo de reprodução inválido.");
        if (string.IsNullOrWhiteSpace(id)) throw new InvalidOperationException("Item sem identificador de reprodução.");
        var ext = (extension ?? string.Empty).Trim().TrimStart('.').ToLowerInvariant();
        if (string.IsNullOrWhiteSpace(ext) || ext.Length > 8 || ext.Any(ch => !char.IsLetterOrDigit(ch)))
            ext = kind == "live" ? LiveExtension : "mp4";
        return $"{BaseUrl}/{kind}/{Uri.EscapeDataString(Username)}/{Uri.EscapeDataString(Password)}/{Uri.EscapeDataString(id)}.{ext}";
    }

    public static string ReadString(JsonObject obj, string key)
    {
        var node = obj[key];
        if (node is null) return string.Empty;
        if (node is JsonValue value)
        {
            if (value.TryGetValue<string>(out var s)) return s ?? string.Empty;
            if (value.TryGetValue<int>(out var i)) return i.ToString();
            if (value.TryGetValue<long>(out var l)) return l.ToString();
            if (value.TryGetValue<bool>(out var b)) return b ? "true" : "false";
        }
        return node.ToString();
    }

    public void Dispose() => _http.Dispose();
}
