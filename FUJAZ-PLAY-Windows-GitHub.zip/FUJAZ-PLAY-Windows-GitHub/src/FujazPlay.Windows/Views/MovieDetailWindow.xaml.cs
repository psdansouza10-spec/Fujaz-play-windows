using System.Text.Json.Nodes;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media.Imaging;
using FujazPlay.Windows.Models;
using FujazPlay.Windows.Services;

namespace FujazPlay.Windows.Views;

public partial class MovieDetailWindow : Window
{
    private readonly AppServices _services;
    private readonly Profile _profile;
    private readonly StreamItem _item;
    private readonly XtreamClient _client;
    private string _plot;

    public MovieDetailWindow(AppServices services, Profile profile, StreamItem item, XtreamClient client)
    {
        InitializeComponent();
        _services = services;
        _profile = profile;
        _item = item;
        _client = client;
        _plot = string.IsNullOrWhiteSpace(item.Plot) ? "Sinopse não informada pelo serviço." : item.Plot;
        TitleText.Text = item.Title;
        MetaText.Text = string.IsNullOrWhiteSpace(item.Rating) ? "FILME" : $"★ {item.Rating}";
        PlotText.Text = _plot;
        TrySetImage(item.IconUrl);
        Loaded += MovieDetailWindow_Loaded;
    }

    private async void MovieDetailWindow_Loaded(object sender, RoutedEventArgs e)
    {
        try
        {
            var root = await _client.GetObjectAsync("get_vod_info", "vod_id", _item.Id);
            var info = root["info"] as JsonObject;
            var movieData = root["movie_data"] as JsonObject;
            var plot = info is null ? string.Empty : XtreamClient.ReadString(info, "plot");
            if (string.IsNullOrWhiteSpace(plot) && info is not null) plot = XtreamClient.ReadString(info, "description");
            if (string.IsNullOrWhiteSpace(plot) && movieData is not null) plot = XtreamClient.ReadString(movieData, "plot");
            if (!string.IsNullOrWhiteSpace(plot)) _plot = plot;
            PlotText.Text = _plot;
        }
        catch { }
    }

    private void TrySetImage(string url)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(url)) return;
            var bmp = new BitmapImage();
            bmp.BeginInit(); bmp.UriSource = new Uri(url, UriKind.Absolute); bmp.CacheOption = BitmapCacheOption.OnLoad; bmp.EndInit();
            PosterImage.Source = bmp;
        }
        catch { }
    }

    private void Play_Click(object sender, RoutedEventArgs e)
    {
        var ext = string.IsNullOrWhiteSpace(_item.Extension) ? "mp4" : _item.Extension;
        var request = new PlaybackRequest
        {
            Kind = "movie", Id = _item.Id, Title = _item.Title, Subtitle = "Filme", IconUrl = _item.IconUrl,
            Extension = ext, Url = _client.StreamUrl("movie", _item.Id, ext)
        };
        new PlayerWindow(_services, _profile, request) { Owner = this }.ShowDialog();
    }

    private void Back_Click(object sender, RoutedEventArgs e) => Close();
    private void Window_KeyDown(object sender, KeyEventArgs e) { if (e.Key == Key.Escape) Close(); }
}
