using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using FujazPlay.Windows.Models;
using FujazPlay.Windows.Services;

namespace FujazPlay.Windows.Views;

public partial class AccountWindow : Window
{
    private readonly AppServices _services;
    private Profile? _active;
    private AccountInfo? _accountInfo;

    public AccountWindow(AppServices services, Profile? active, AccountInfo? accountInfo)
    {
        InitializeComponent();
        _services = services;
        _active = active;
        _accountInfo = accountInfo;
        Loaded += (_, _) => ReloadProfiles();
    }

    private void ReloadProfiles(string? selectId = null)
    {
        _active = _services.Profiles.GetActiveProfile();
        var profiles = _services.Profiles.LoadProfiles().ToList();
        ProfilesList.ItemsSource = profiles;
        var id = selectId ?? _active?.Id;
        ProfilesList.SelectedItem = profiles.FirstOrDefault(x => x.Id == id) ?? profiles.FirstOrDefault();
        ShowSelected();
    }

    private void ProfilesList_SelectionChanged(object sender, SelectionChangedEventArgs e) => ShowSelected();

    private void ShowSelected()
    {
        var selected = ProfilesList.SelectedItem as Profile;
        if (selected is null) return;
        var active = _active?.Id == selected.Id;
        SelectedNameText.Text = selected.DisplayName;
        SelectedStateText.Text = active ? "● ATIVA" : "Lista salva";
        UserText.Text = selected.Username;
        if (active && _accountInfo is not null)
        {
            StatusText.Text = string.IsNullOrWhiteSpace(_accountInfo.Status) ? "Conectada" : TranslateStatus(_accountInfo.Status);
            ExpiryText.Text = FormatExpiry(_accountInfo.ExpDate);
            ConnectionsText.Text = BuildConnections(_accountInfo);
        }
        else
        {
            StatusText.Text = active ? "Conectada" : "Conecte para consultar";
            ExpiryText.Text = active ? "Não informada" : "—";
            ConnectionsText.Text = string.Empty;
        }
    }

    private static string TranslateStatus(string raw) => raw.ToLowerInvariant() switch
    {
        "active" => "Ativa", "expired" => "Expirada", "banned" => "Bloqueada", "disabled" => "Desativada", _ => raw
    };

    private static string FormatExpiry(string raw)
    {
        if (string.IsNullOrWhiteSpace(raw)) return "Não informada pelo serviço";
        if (raw == "0") return "Sem vencimento informado";
        if (long.TryParse(raw, out var seconds) && seconds > 0)
            return DateTimeOffset.FromUnixTimeSeconds(seconds).LocalDateTime.ToString("g", new CultureInfo("pt-BR"));
        return raw;
    }

    private static string BuildConnections(AccountInfo info)
    {
        var parts = new List<string>();
        if (!string.IsNullOrWhiteSpace(info.MaxConnections)) parts.Add($"Telas permitidas: {info.MaxConnections}");
        if (!string.IsNullOrWhiteSpace(info.ActiveConnections)) parts.Add($"Em uso: {info.ActiveConnections}");
        return string.Join("  •  ", parts);
    }

    private async void Connect_Click(object sender, RoutedEventArgs e)
    {
        if (ProfilesList.SelectedItem is not Profile selected) return;
        try
        {
            using var client = new XtreamClient(selected.Dns, selected.Username, _services.Profiles.GetPassword(selected));
            SelectedStateText.Text = "Conectando…";
            var info = await client.LoginAsync();
            _services.Profiles.SetActive(selected.Id);
            _active = selected;
            _accountInfo = info;
            ShowSelected();
        }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "FUJAZ PLAY", MessageBoxButton.OK, MessageBoxImage.Error); }
    }

    private void Add_Click(object sender, RoutedEventArgs e)
    {
        var window = new LoginWindow(_services) { Owner = this };
        if (window.ShowDialog() == true && window.SavedProfile is not null)
        {
            _accountInfo = null;
            ReloadProfiles(window.SavedProfile.Id);
        }
    }

    private void Edit_Click(object sender, RoutedEventArgs e)
    {
        if (ProfilesList.SelectedItem is not Profile selected) return;
        var window = new LoginWindow(_services, selected, activateOnSave: _active?.Id == selected.Id) { Owner = this };
        if (window.ShowDialog() == true && window.SavedProfile is not null)
        {
            _accountInfo = null;
            ReloadProfiles(window.SavedProfile.Id);
        }
    }

    private void Delete_Click(object sender, RoutedEventArgs e)
    {
        if (ProfilesList.SelectedItem is not Profile selected) return;
        if (_active?.Id == selected.Id)
        {
            MessageBox.Show(this, "Esta lista está em uso. Troque para outra lista antes de excluir.", "FUJAZ PLAY");
            return;
        }
        if (MessageBox.Show(this, $"Deseja excluir a lista {selected.DisplayName}?", "Excluir lista?", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
        {
            _services.Profiles.DeleteProfile(selected.Id);
            ReloadProfiles();
        }
    }

    private async void UpdateAccount_Click(object sender, RoutedEventArgs e)
    {
        _active = _services.Profiles.GetActiveProfile();
        if (_active is null) return;
        try
        {
            SelectedStateText.Text = "Atualizando sua conta…";
            using var client = new XtreamClient(_active.Dns, _active.Username, _services.Profiles.GetPassword(_active));
            _accountInfo = await client.LoginAsync();
            ReloadProfiles(_active.Id);
        }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "FUJAZ PLAY", MessageBoxButton.OK, MessageBoxImage.Error); }
    }

    private void Back_Click(object sender, RoutedEventArgs e) => Close();
    private void Window_KeyDown(object sender, KeyEventArgs e) { if (e.Key == Key.Escape) Close(); }
}
