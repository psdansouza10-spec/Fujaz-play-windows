using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using FujazPlay.Windows.Models;
using FujazPlay.Windows.Services;

namespace FujazPlay.Windows.Views;

public partial class CatalogWindow : Window
{
    private readonly AppServices _services;
    private readonly Profile _profile;
    private readonly CatalogSection _section;
    private readonly ContentCache _cache;
    private readonly string? _forcedCategoryId;
    private readonly List<CategoryItem> _categories;
    private readonly List<StreamItem> _allItems;
    private List<StreamItem> _visible = new();
    private XtreamClient? _client;

    public CatalogWindow(AppServices services, Profile profile, CatalogSection section, ContentCache cache, string? forcedCategoryId = null, string? titleOverride = null)
    {
        InitializeComponent();
        _services = services;
        _profile = profile;
        _section = section;
        _cache = cache;
        _forcedCategoryId = forcedCategoryId;

        (_categories, _allItems) = section switch
        {
            CatalogSection.Live => (cache.LiveCategories, cache.LiveStreams),
            CatalogSection.Movies => (cache.VodCategories, cache.VodStreams),
            _ => (cache.SeriesCategories, cache.Series)
        };

        HeadingText.Text = titleOverride ?? (section switch
        {
            CatalogSection.Live => "CANAIS AO VIVO",
            CatalogSection.Movies => "FILMES",
            _ => "SÉRIES"
        });

        Loaded += CatalogWindow_Loaded;
        Closed += (_, _) => _client?.Dispose();
    }

    private async void CatalogWindow_Loaded(object sender, RoutedEventArgs e)
    {
        if (_forcedCategoryId is not null)
        {
            var only = _categories.FirstOrDefault(c => c.Id == _forcedCategoryId);
            CategoriesList.ItemsSource = only is null ? Array.Empty<CategoryItem>() : new[] { only };
        }
        else CategoriesList.ItemsSource = _categories;

        if (CategoriesList.Items.Count > 0) CategoriesList.SelectedIndex = 0;
        ApplyFilter();
        ItemsList.Focus();
        try { await EnsureClientAsync(); } catch { }
    }

    private async Task<XtreamClient> EnsureClientAsync()
    {
        if (_client is not null) return _client;
        _client = new XtreamClient(_profile.Dns, _profile.Username, _services.Profiles.GetPassword(_profile));
        await _client.LoginAsync();
        return _client;
    }

    private void ApplyFilter()
    {
        var query = SearchBox.Text.Trim();
        if (!string.IsNullOrWhiteSpace(query))
        {
            _visible = _allItems.Where(x => x.Title.Contains(query, StringComparison.CurrentCultureIgnoreCase)).ToList();
        }
        else
        {
            var categoryId = (CategoriesList.SelectedItem as CategoryItem)?.Id ?? _forcedCategoryId ?? string.Empty;
            _visible = string.IsNullOrWhiteSpace(categoryId) ? new List<StreamItem>() : _allItems.Where(x => x.CategoryId == categoryId).ToList();
        }
        ItemsList.ItemsSource = null;
        ItemsList.ItemsSource = _visible;
        CountText.Text = $"{_visible.Count:N0} itens";
        if (_visible.Count > 0) ItemsList.SelectedIndex = 0;
    }

    private void CategoriesList_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (string.IsNullOrWhiteSpace(SearchBox.Text)) ApplyFilter();
    }

    private void SearchBox_TextChanged(object sender, TextChangedEventArgs e) => ApplyFilter();

    private async Task OpenSelectedAsync()
    {
        if (ItemsList.SelectedItem is not StreamItem item) return;
        try
        {
            var client = await EnsureClientAsync();
            if (_section == CatalogSection.Live)
            {
                var request = new PlaybackRequest
                {
                    Kind = "live", Id = item.Id, Title = item.Title, IconUrl = item.IconUrl,
                    Extension = string.IsNullOrWhiteSpace(item.Extension) ? client.LiveExtension : item.Extension,
                    Url = client.StreamUrl("live", item.Id, string.IsNullOrWhiteSpace(item.Extension) ? client.LiveExtension : item.Extension)
                };
                var index = Math.Max(0, _visible.IndexOf(item));
                new PlayerWindow(_services, _profile, request, _visible.ToList(), index) { Owner = this }.ShowDialog();
            }
            else if (_section == CatalogSection.Movies)
            {
                new MovieDetailWindow(_services, _profile, item, client) { Owner = this }.ShowDialog();
            }
            else
            {
                new SeriesWindow(_services, _profile, item) { Owner = this }.ShowDialog();
            }
        }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "FUJAZ PLAY", MessageBoxButton.OK, MessageBoxImage.Error); }
    }

    private async void ItemsList_MouseDoubleClick(object sender, MouseButtonEventArgs e) => await OpenSelectedAsync();
    private async void ItemsList_KeyDown(object sender, KeyEventArgs e) { if (e.Key == Key.Enter) { e.Handled = true; await OpenSelectedAsync(); } }
    private void Window_KeyDown(object sender, KeyEventArgs e) { if (e.Key == Key.Escape) Close(); }
}
