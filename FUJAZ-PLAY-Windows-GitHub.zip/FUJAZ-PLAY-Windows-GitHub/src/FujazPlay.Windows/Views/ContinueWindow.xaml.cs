using System.Windows;
using System.Windows.Input;
using FujazPlay.Windows.Models;
using FujazPlay.Windows.Services;

namespace FujazPlay.Windows.Views;

public partial class ContinueWindow : Window
{
    private readonly AppServices _services;
    private readonly Profile _profile;

    public ContinueWindow(AppServices services, Profile profile)
    {
        InitializeComponent();
        _services = services;
        _profile = profile;
        Loaded += (_, _) => Reload();
    }

    private void Reload()
    {
        var items = _services.History.ContinueWatching(_profile.Id);
        HistoryList.ItemsSource = items;
        if (items.Count > 0) HistoryList.SelectedIndex = 0;
    }

    private async Task PlaySelectedAsync()
    {
        if (HistoryList.SelectedItem is not HistoryEntry entry) return;
        try
        {
            using var client = new XtreamClient(_profile.Dns, _profile.Username, _services.Profiles.GetPassword(_profile));
            await client.LoginAsync();
            var ext = string.IsNullOrWhiteSpace(entry.Extension) ? "mp4" : entry.Extension;
            var req = new PlaybackRequest
            {
                Kind = entry.Kind, Id = entry.Id, ParentId = entry.ParentId, Title = entry.Title, Subtitle = entry.Subtitle,
                IconUrl = entry.IconUrl, Extension = ext, Url = client.StreamUrl(entry.Kind, entry.Id, ext)
            };
            new PlayerWindow(_services, _profile, req) { Owner = this }.ShowDialog();
            Reload();
        }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "FUJAZ PLAY", MessageBoxButton.OK, MessageBoxImage.Error); }
    }

    private async void HistoryList_MouseDoubleClick(object sender, MouseButtonEventArgs e) => await PlaySelectedAsync();
    private async void HistoryList_KeyDown(object sender, KeyEventArgs e) { if (e.Key == Key.Enter) { e.Handled = true; await PlaySelectedAsync(); } }
    private void Back_Click(object sender, RoutedEventArgs e) => Close();
    private void Window_KeyDown(object sender, KeyEventArgs e) { if (e.Key == Key.Escape) Close(); }
}
