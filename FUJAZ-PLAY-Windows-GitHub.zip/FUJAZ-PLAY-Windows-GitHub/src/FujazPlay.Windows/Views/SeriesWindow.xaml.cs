using System.Text.Json.Nodes;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using FujazPlay.Windows.Models;
using FujazPlay.Windows.Services;

namespace FujazPlay.Windows.Views;

public partial class SeriesWindow : Window
{
    private readonly AppServices _services;
    private readonly Profile _profile;
    private readonly StreamItem _series;
    private readonly SortedDictionary<int, List<EpisodeItem>> _seasons = new();
    private XtreamClient? _client;

    public SeriesWindow(AppServices services, Profile profile, StreamItem series)
    {
        InitializeComponent();
        _services = services;
        _profile = profile;
        _series = series;
        TitleText.Text = series.Title;
        Loaded += SeriesWindow_Loaded;
        Closed += (_, _) => _client?.Dispose();
    }

    private async void SeriesWindow_Loaded(object sender, RoutedEventArgs e)
    {
        StatusText.Text = "Carregando temporadas e episódios…";
        try
        {
            _client = new XtreamClient(_profile.Dns, _profile.Username, _services.Profiles.GetPassword(_profile));
            await _client.LoginAsync();
            var root = await _client.GetObjectAsync("get_series_info", "series_id", _series.Id);
            ParseEpisodes(root);
            SeasonsList.ItemsSource = _seasons.Keys.Select(n => n == 0 ? "Especiais" : $"Temporada {n}").ToList();
            if (SeasonsList.Items.Count > 0) SeasonsList.SelectedIndex = 0;
            StatusText.Text = _seasons.Count == 0 ? "O servidor não retornou episódios para esta série." : $"{_seasons.Sum(x => x.Value.Count)} episódios";
            EpisodesList.Focus();
        }
        catch (Exception ex) { StatusText.Text = ex.Message; }
    }

    private void ParseEpisodes(JsonObject root)
    {
        JsonNode? raw = root["episodes"];
        if (raw is null && root["data"] is JsonObject data) raw = data["episodes"];
        if (raw is JsonObject bySeason)
        {
            foreach (var kv in bySeason)
            {
                int.TryParse(kv.Key, out var seasonNumber);
                if (kv.Value is JsonArray arr) AddArray(seasonNumber, arr);
            }
        }
        else if (raw is JsonArray flat) AddArray(-1, flat);
    }

    private void AddArray(int seasonHint, JsonArray array)
    {
        foreach (var node in array)
        {
            if (node is not JsonObject obj) continue;
            var season = seasonHint >= 0 ? seasonHint : ParseInt(obj, "season", 0);
            var epNum = ParseInt(obj, "episode_num", ParseInt(obj, "episode", 0));
            var id = XtreamClient.ReadString(obj, "id");
            if (string.IsNullOrWhiteSpace(id)) id = XtreamClient.ReadString(obj, "stream_id");
            if (string.IsNullOrWhiteSpace(id)) continue;
            var title = XtreamClient.ReadString(obj, "title");
            if (string.IsNullOrWhiteSpace(title)) title = epNum > 0 ? $"Episódio {epNum}" : "Episódio";
            var ext = XtreamClient.ReadString(obj, "container_extension");
            var info = obj["info"] as JsonObject;
            var icon = info is null ? string.Empty : XtreamClient.ReadString(info, "movie_image");
            if (string.IsNullOrWhiteSpace(icon) && info is not null) icon = XtreamClient.ReadString(info, "cover_big");
            var plot = info is null ? string.Empty : XtreamClient.ReadString(info, "plot");
            if (!_seasons.TryGetValue(season, out var list)) _seasons[season] = list = new List<EpisodeItem>();
            list.Add(new EpisodeItem { Id = id, SeriesId = _series.Id, SeriesTitle = _series.Title, Title = title, Season = season, Episode = epNum, Extension = string.IsNullOrWhiteSpace(ext) ? "mp4" : ext, IconUrl = icon, Plot = plot });
        }
        foreach (var list in _seasons.Values) list.Sort((a, b) => a.Episode.CompareTo(b.Episode));
    }

    private static int ParseInt(JsonObject obj, string key, int fallback)
    {
        var s = XtreamClient.ReadString(obj, key);
        return int.TryParse(s, out var value) ? value : fallback;
    }

    private void SeasonsList_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (SeasonsList.SelectedIndex < 0 || SeasonsList.SelectedIndex >= _seasons.Count) return;
        var season = _seasons.Keys.ElementAt(SeasonsList.SelectedIndex);
        EpisodesList.ItemsSource = _seasons[season];
        if (EpisodesList.Items.Count > 0) EpisodesList.SelectedIndex = 0;
    }

    private void PlaySelected()
    {
        if (_client is null || EpisodesList.SelectedItem is not EpisodeItem ep) return;
        var request = new PlaybackRequest
        {
            Kind = "series", Id = ep.Id, ParentId = ep.SeriesId, Title = ep.SeriesTitle,
            Subtitle = ep.Season > 0 ? $"Temporada {ep.Season} • Episódio {ep.Episode}" : ep.Title,
            IconUrl = string.IsNullOrWhiteSpace(ep.IconUrl) ? _series.IconUrl : ep.IconUrl,
            Extension = ep.Extension,
            Url = _client.StreamUrl("series", ep.Id, ep.Extension)
        };
        new PlayerWindow(_services, _profile, request) { Owner = this }.ShowDialog();
    }

    private void EpisodesList_MouseDoubleClick(object sender, MouseButtonEventArgs e) => PlaySelected();
    private void EpisodesList_KeyDown(object sender, KeyEventArgs e) { if (e.Key == Key.Enter) { e.Handled = true; PlaySelected(); } }
    private void Back_Click(object sender, RoutedEventArgs e) => Close();
    private void Window_KeyDown(object sender, KeyEventArgs e) { if (e.Key == Key.Escape) Close(); }
}
