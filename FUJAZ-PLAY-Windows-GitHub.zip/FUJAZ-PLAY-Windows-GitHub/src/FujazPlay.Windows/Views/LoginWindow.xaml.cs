using System.Windows;
using FujazPlay.Windows.Models;
using FujazPlay.Windows.Services;

namespace FujazPlay.Windows.Views;

public partial class LoginWindow : Window
{
    private readonly AppServices _services;
    private readonly Profile? _editing;
    private readonly bool _activateOnSave;
    private readonly bool _initialLogin;
    private bool _syncingPassword;
    private bool _passwordVisible;
    public Profile? SavedProfile { get; private set; }

    public LoginWindow(AppServices services, Profile? editing = null, bool activateOnSave = true, bool initialLogin = false)
    {
        InitializeComponent();
        _services = services;
        _editing = editing;
        _activateOnSave = activateOnSave;
        _initialLogin = initialLogin;

        if (_initialLogin)
        {
            Title = "FUJAZ PLAY - Login";
            TitleText.Text = "Entrar no FUJAZ PLAY";
            SubtitleText.Text = "Adicione sua lista para acessar canais, filmes e séries.";
            SaveButton.Content = "ENTRAR";
            CancelButton.Content = "SAIR";
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            WindowState = WindowState.Maximized;
        }
        else if (editing is not null)
        {
            TitleText.Text = "Editar lista";
            SubtitleText.Text = "Atualize os dados desta lista e conecte novamente.";
            SaveButton.Content = "SALVAR E CONECTAR";
            CancelButton.Content = "CANCELAR";
            NameBox.Text = editing.Name;
            UserBox.Text = editing.Username;
            DnsBox.Text = editing.Dns;
            PasswordBox.Password = _services.Profiles.GetPassword(editing);
            VisiblePasswordBox.Text = PasswordBox.Password;
        }
        else
        {
            TitleText.Text = "Adicionar outra lista";
            SubtitleText.Text = "Cada lista fica separada com seus próprios conteúdos e histórico.";
            SaveButton.Content = "ADICIONAR E CONECTAR";
            CancelButton.Content = "CANCELAR";
        }

        Loaded += (_, _) => NameBox.Focus();
    }

    private string CurrentPassword => _passwordVisible ? VisiblePasswordBox.Text : PasswordBox.Password;

    private void TogglePassword_Click(object sender, RoutedEventArgs e)
    {
        _syncingPassword = true;
        try
        {
            if (_passwordVisible)
            {
                PasswordBox.Password = VisiblePasswordBox.Text;
                VisiblePasswordBox.Visibility = Visibility.Collapsed;
                PasswordBox.Visibility = Visibility.Visible;
                TogglePasswordButton.Content = "👁";
                _passwordVisible = false;
                PasswordBox.Focus();
            }
            else
            {
                VisiblePasswordBox.Text = PasswordBox.Password;
                PasswordBox.Visibility = Visibility.Collapsed;
                VisiblePasswordBox.Visibility = Visibility.Visible;
                TogglePasswordButton.Content = "🙈";
                _passwordVisible = true;
                VisiblePasswordBox.Focus();
                VisiblePasswordBox.CaretIndex = VisiblePasswordBox.Text.Length;
            }
        }
        finally { _syncingPassword = false; }
    }

    private void PasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
    {
        if (_syncingPassword || _passwordVisible) return;
        _syncingPassword = true;
        VisiblePasswordBox.Text = PasswordBox.Password;
        _syncingPassword = false;
    }

    private void VisiblePasswordBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
    {
        if (_syncingPassword || !_passwordVisible) return;
        _syncingPassword = true;
        PasswordBox.Password = VisiblePasswordBox.Text;
        _syncingPassword = false;
    }

    private async void Save_Click(object sender, RoutedEventArgs e)
    {
        ErrorText.Text = string.Empty;

        var username = UserBox.Text.Trim();
        var dns = DnsBox.Text.Trim();
        var password = CurrentPassword;
        if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password) || string.IsNullOrWhiteSpace(dns))
        {
            ErrorText.Text = "Preencha usuário, senha e DNS/servidor.";
            return;
        }

        SaveButton.IsEnabled = false;
        CancelButton.IsEnabled = false;
        try
        {
            var profile = _editing ?? new Profile();
            profile.Name = string.IsNullOrWhiteSpace(NameBox.Text) ? "Minha Lista" : NameBox.Text.Trim();
            profile.Username = username;
            profile.Dns = dns;

            using var client = new XtreamClient(profile.Dns, profile.Username, password);
            var originalText = SaveButton.Content;
            SaveButton.Content = "CONECTANDO…";
            await client.LoginAsync();

            _services.Profiles.SaveProfile(profile, password);
            if (_activateOnSave) _services.Profiles.SetActive(profile.Id);
            SavedProfile = profile;
            DialogResult = true;
        }
        catch (Exception ex)
        {
            ErrorText.Text = ex.Message;
            SaveButton.IsEnabled = true;
            CancelButton.IsEnabled = true;
            SaveButton.Content = _initialLogin ? "ENTRAR" : (_editing is null ? "ADICIONAR E CONECTAR" : "SALVAR E CONECTAR");
        }
    }

    private void Cancel_Click(object sender, RoutedEventArgs e) => DialogResult = false;
}
