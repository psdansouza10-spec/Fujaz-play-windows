using System.Windows;
using FujazPlay.Windows.Models;
using FujazPlay.Windows.Services;

namespace FujazPlay.Windows.Views;

public partial class LoginWindow : Window
{
    private readonly AppServices _services;
    private readonly Profile? _editing;
    private readonly bool _activateOnSave;
    public Profile? SavedProfile { get; private set; }

    public LoginWindow(AppServices services, Profile? editing = null, bool activateOnSave = true)
    {
        InitializeComponent();
        _services = services;
        _editing = editing;
        _activateOnSave = activateOnSave;
        if (editing is not null)
        {
            TitleText.Text = "Editar lista";
            SaveButton.Content = "SALVAR E CONECTAR";
            NameBox.Text = editing.Name;
            UserBox.Text = editing.Username;
            DnsBox.Text = editing.Dns;
            PasswordBox.Password = _services.Profiles.GetPassword(editing);
        }
        Loaded += (_, _) => NameBox.Focus();
    }

    private async void Save_Click(object sender, RoutedEventArgs e)
    {
        ErrorText.Text = string.Empty;
        SaveButton.IsEnabled = false;
        try
        {
            var profile = _editing ?? new Profile();
            profile.Name = string.IsNullOrWhiteSpace(NameBox.Text) ? "Minha Lista" : NameBox.Text.Trim();
            profile.Username = UserBox.Text.Trim();
            profile.Dns = DnsBox.Text.Trim();
            var password = PasswordBox.Password;

            using var client = new XtreamClient(profile.Dns, profile.Username, password);
            SaveButton.Content = "CONECTANDO…";
            await client.LoginAsync();

            _services.Profiles.SaveProfile(profile, password);
            if (_activateOnSave) _services.Profiles.SetActive(profile.Id);
            SavedProfile = profile;
            DialogResult = true;
        }
        catch (Exception ex)
        {
            ErrorText.Text = ex.Message;
            SaveButton.IsEnabled = true;
            SaveButton.Content = _editing is null ? "ADICIONAR E CONECTAR" : "SALVAR E CONECTAR";
        }
    }

    private void Cancel_Click(object sender, RoutedEventArgs e) => DialogResult = false;
}
