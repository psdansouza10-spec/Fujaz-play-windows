using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;
using FujazPlay.Windows.Models;
using FujazPlay.Windows.Services;
using LibVLCSharp.Shared;

namespace FujazPlay.Windows.Views;

public partial class PlayerWindow : Window
{
    private readonly AppServices _services;
    private readonly Profile _profile;
    private PlaybackRequest _request;
    private readonly List<StreamItem> _livePlaylist;
    private int _liveIndex;
    private LibVLC? _libVlc;
    private MediaPlayer? _mediaPlayer;
    private Media? _media;
    private XtreamClient? _liveClient;
    private readonly DispatcherTimer _uiTimer = new() { Interval = TimeSpan.FromSeconds(1) };
    private readonly DispatcherTimer _overlayTimer = new() { Interval = TimeSpan.FromSeconds(5) };
    private bool _seeking;
    private bool _resumeApplied;

    public PlayerWindow(AppServices services, Profile profile, PlaybackRequest request, List<StreamItem>? livePlaylist = null, int liveIndex = 0)
    {
        InitializeComponent();
        _services = services;
        _profile = profile;
        _request = request;
        _livePlaylist = livePlaylist ?? new List<StreamItem>();
        _liveIndex = Math.Clamp(liveIndex, 0, Math.Max(0, _livePlaylist.Count - 1));

        _overlayTimer.Tick += (_, _) => HideLiveOverlay();
        _uiTimer.Tick += (_, _) => RefreshPlayerUi();
        Loaded += PlayerWindow_Loaded;
        Closed += PlayerWindow_Closed;
    }

    private async void PlayerWindow_Loaded(object sender, RoutedEventArgs e)
    {
        TitleText.Text = _request.Title;
        SubtitleText.Text = _request.Subtitle;
        VodProgressGrid.Visibility = _request.IsLive ? Visibility.Collapsed : Visibility.Visible;
        HintText.Text = _request.IsLive ? "ENTER lista de canais   ESC voltar   F11 tela cheia" : "←/→ voltar/adiantar 15s   ESC voltar   F11 tela cheia";
        if (_request.IsLive && _livePlaylist.Count > 0)
        {
            ChannelList.ItemsSource = _livePlaylist;
            ChannelList.SelectedIndex = _liveIndex;
            try
            {
                _liveClient = new XtreamClient(_profile.Dns, _profile.Username, _services.Profiles.GetPassword(_profile));
                await _liveClient.LoginAsync();
            }
            catch { }
        }

        try
        {
            _libVlc = new LibVLC("--network-caching=1200", "--file-caching=800", "--no-video-title-show");
            _mediaPlayer = new MediaPlayer(_libVlc);
            _mediaPlayer.EncounteredError += (_, _) => Dispatcher.Invoke(() => ShowError("O player encontrou um erro ao abrir este conteúdo."));
            _mediaPlayer.EndReached += (_, _) => Dispatcher.Invoke(() => SaveProgress(true));
            _mediaPlayer.Playing += (_, _) => Dispatcher.InvokeAsync(async () => { await Task.Delay(450); ApplyResumePosition(); });
            VideoView.MediaPlayer = _mediaPlayer;
            VolumeSlider.Value = 80;
            PlayRequest(_request);
            _uiTimer.Start();
        }
        catch (Exception ex) { ShowError(ex.Message); }
    }

    private void PlayRequest(PlaybackRequest request)
    {
        if (_mediaPlayer is null || _libVlc is null) return;
        _request = request;
        _resumeApplied = false;
        TitleText.Text = request.Title;
        SubtitleText.Text = request.Subtitle;
        _media?.Dispose();
        _media = new Media(_libVlc, request.Url, FromType.FromLocation);
        _media.AddOption(":network-caching=1200");
        if (!_mediaPlayer.Play(_media)) ShowError("O VLC não conseguiu iniciar esta transmissão.");
    }

    private void ApplyResumePosition()
    {
        if (_resumeApplied || _mediaPlayer is null || _request.IsLive) return;
        _resumeApplied = true;
        var old = _services.History.Get(_profile.Id, HistoryStore.KeyFor(_request));
        if (old is not null && !old.Completed && old.PositionMs > 10_000 && old.DurationMs > 0 && old.PositionMs < old.DurationMs * 0.95)
            _mediaPlayer.Time = old.PositionMs;
    }

    private void RefreshPlayerUi()
    {
        if (_mediaPlayer is null || _request.IsLive) return;
        var length = Math.Max(0, _mediaPlayer.Length);
        var time = Math.Max(0, _mediaPlayer.Time);
        if (!_seeking)
        {
            ProgressSlider.Maximum = Math.Max(1, length);
            ProgressSlider.Value = Math.Min(time, ProgressSlider.Maximum);
        }
        CurrentText.Text = FormatTime(time);
        DurationText.Text = FormatTime(length);
        if (time > 0) SaveProgress(false);
    }

    private static string FormatTime(long ms)
    {
        var t = TimeSpan.FromMilliseconds(Math.Max(0, ms));
        return t.TotalHours >= 1 ? $"{(int)t.TotalHours:00}:{t.Minutes:00}:{t.Seconds:00}" : $"{t.Minutes:00}:{t.Seconds:00}";
    }

    private void SaveProgress(bool completed)
    {
        if (_mediaPlayer is null || _request.IsLive) return;
        _services.History.Save(_profile.Id, _request, Math.Max(0, _mediaPlayer.Time), Math.Max(0, _mediaPlayer.Length), completed);
    }

    private void ShowLiveOverlay()
    {
        if (!_request.IsLive || _livePlaylist.Count == 0) return;
        LiveOverlay.Visibility = Visibility.Visible;
        ChannelList.SelectedIndex = _liveIndex;
        ChannelList.ScrollIntoView(ChannelList.SelectedItem);
        ChannelList.Focus();
        RestartOverlayTimer();
    }

    private void HideLiveOverlay()
    {
        _overlayTimer.Stop();
        LiveOverlay.Visibility = Visibility.Collapsed;
        Focus();
    }

    private void RestartOverlayTimer()
    {
        _overlayTimer.Stop();
        _overlayTimer.Start();
    }

    private void SwitchSelectedChannel()
    {
        if (ChannelList.SelectedItem is not StreamItem item || _liveClient is null) return;
        _liveIndex = Math.Max(0, ChannelList.SelectedIndex);
        var ext = string.IsNullOrWhiteSpace(item.Extension) ? _liveClient.LiveExtension : item.Extension;
        var req = new PlaybackRequest
        {
            Kind = "live", Id = item.Id, Title = item.Title, IconUrl = item.IconUrl, Extension = ext,
            Url = _liveClient.StreamUrl("live", item.Id, ext)
        };
        PlayRequest(req);
        RestartOverlayTimer();
    }

    private void Window_PreviewKeyDown(object sender, KeyEventArgs e)
    {
        if (LiveOverlay.Visibility == Visibility.Visible && e.Key is Key.Up or Key.Down or Key.Left or Key.Right or Key.Enter)
            RestartOverlayTimer();
    }

    private void Window_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.F11)
        {
            WindowStyle = WindowStyle == WindowStyle.None ? WindowStyle.SingleBorderWindow : WindowStyle.None;
            WindowState = WindowState.Maximized;
            e.Handled = true;
            return;
        }

        if (e.Key == Key.Escape)
        {
            if (LiveOverlay.Visibility == Visibility.Visible) HideLiveOverlay(); else Close();
            e.Handled = true;
            return;
        }

        if (_request.IsLive)
        {
            if (e.Key == Key.Enter)
            {
                if (LiveOverlay.Visibility == Visibility.Visible) SwitchSelectedChannel(); else ShowLiveOverlay();
                e.Handled = true;
                return;
            }
            if (LiveOverlay.Visibility == Visibility.Visible && e.Key is Key.Up or Key.Down or Key.Left or Key.Right)
                RestartOverlayTimer();
        }
        else if (_mediaPlayer is not null)
        {
            if (e.Key == Key.Right) { _mediaPlayer.Time = Math.Min(_mediaPlayer.Length, _mediaPlayer.Time + 15_000); e.Handled = true; }
            else if (e.Key == Key.Left) { _mediaPlayer.Time = Math.Max(0, _mediaPlayer.Time - 15_000); e.Handled = true; }
            else if (e.Key == Key.Space) { _mediaPlayer.SetPause(_mediaPlayer.IsPlaying); e.Handled = true; }
        }
    }

    private void Window_MouseMove(object sender, MouseEventArgs e)
    {
        if (LiveOverlay.Visibility == Visibility.Visible) RestartOverlayTimer();
    }

    private void ChannelList_MouseDoubleClick(object sender, MouseButtonEventArgs e) => SwitchSelectedChannel();

    private void ProgressSlider_PreviewMouseDown(object sender, MouseButtonEventArgs e) => _seeking = true;
    private void ProgressSlider_PreviewMouseUp(object sender, MouseButtonEventArgs e)
    {
        if (_mediaPlayer is not null) _mediaPlayer.Time = (long)ProgressSlider.Value;
        _seeking = false;
    }

    private void VolumeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        if (_mediaPlayer is not null) _mediaPlayer.Volume = (int)e.NewValue;
    }

    private void ShowError(string text)
    {
        ErrorText.Text = text;
        ErrorBorder.Visibility = Visibility.Visible;
    }

    private void PlayerWindow_Closed(object? sender, EventArgs e)
    {
        try { SaveProgress(false); } catch { }
        _overlayTimer.Stop();
        _uiTimer.Stop();
        try { _mediaPlayer?.Stop(); } catch { }
        _media?.Dispose();
        _mediaPlayer?.Dispose();
        _libVlc?.Dispose();
        _liveClient?.Dispose();
    }
}
